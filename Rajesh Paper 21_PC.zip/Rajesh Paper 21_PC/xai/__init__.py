"""
Explainable AI (XAI) Module using SHAP.
Interprets resource allocation, UE inclusion, and slice management decisions
for 6G massive IoT networks.
"""

from .shap_explainer import ResourceAllocationExplainer

__all__ = ['ResourceAllocationExplainer']
