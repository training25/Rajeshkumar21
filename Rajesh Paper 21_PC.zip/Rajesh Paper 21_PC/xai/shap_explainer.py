"""
SHAP-Based Explainable AI for 6G-IoTMesh Resource Allocation.
Provides local and global feature attribution for UE inclusion,
bandwidth provisioning, and slicing decisions, ensuring transparency.
"""

import numpy as np
import pandas as pd
import torch
from typing import Dict, List, Any, Optional

try:
    import shap
    SHAP_AVAILABLE = True
except ImportError:
    SHAP_AVAILABLE = False


class ResourceAllocationExplainer:
    """
    Computes Shapley values (SHAP) to interpret policy gradient decisions.
    Supports both official SHAP library and native Monte Carlo Shapley calculation.
    """
    def __init__(self, agent_model, feature_names: List[str], temporal_window: int = 5):
        self.model = agent_model
        self.feature_names = feature_names
        self.temporal_window = temporal_window
        self.num_features = len(feature_names)

    def _predict_wrapper(self, flat_features: np.ndarray, target_head: str = 'bw') -> np.ndarray:
        """
        Wrapper converting 2D feature matrix (samples, num_features) to
        spatio-temporal input (samples, Tw, D) and predicting model outputs.
        target_head: 'inclusion', 'power', 'bw', or 'offload'
        """
        num_samples = flat_features.shape[0]
        # Replicate feature vector across temporal window to feed encoder
        spatio_temp = np.repeat(flat_features[:, np.newaxis, :], self.temporal_window, axis=1) # (B, Tw, D)
        
        self.model.eval()
        with torch.no_grad():
            t_input = torch.from_numpy(spatio_temp).float()
            # Unsqueeze to add node dimension (B, 1, Tw, D)
            t_input = t_input.unsqueeze(1)
            latent = self.model.encoder(t_input).squeeze(1) # (B, latent_dim)

            if target_head == 'inclusion':
                out = self.model.actor_inclusion(latent).squeeze(-1)
            elif target_head == 'power':
                out = self.model.actor_resource_mean(latent)[:, 0]
            elif target_head == 'bw':
                out = self.model.actor_resource_mean(latent)[:, 1]
            elif target_head == 'offload':
                out = self.model.actor_resource_mean(latent)[:, 2]
            else:
                out = self.model.actor_inclusion(latent).squeeze(-1)

        return out.cpu().numpy()

    def compute_shapley_values_native(self, background_data: np.ndarray,
                                      sample_instances: np.ndarray,
                                      target_head: str = 'bw',
                                      num_monte_carlo: int = 40) -> np.ndarray:
        """
        Native Monte-Carlo Shapley value estimation.
        Guarantees guaranteed execution without external library dependency.
        """
        num_samples = sample_instances.shape[0]
        shap_values = np.zeros((num_samples, self.num_features))
        base_value = np.mean(self._predict_wrapper(background_data, target_head=target_head))

        for s_idx in range(num_samples):
            x = sample_instances[s_idx]
            val_x = self._predict_wrapper(x[np.newaxis, :], target_head=target_head)[0]

            for f_idx in range(self.num_features):
                phi_f = 0.0
                for _ in range(num_monte_carlo):
                    # Random permutation of feature indices
                    perm = np.random.permutation(self.num_features)
                    f_pos = np.where(perm == f_idx)[0][0]
                    
                    # Random baseline reference instance from background
                    bg_ref = background_data[np.random.randint(len(background_data))]

                    # Hybrid vector before adding f_idx
                    v_without = bg_ref.copy()
                    v_without[perm[:f_pos]] = x[perm[:f_pos]]

                    # Hybrid vector after adding f_idx
                    v_with = v_without.copy()
                    v_with[f_idx] = x[f_idx]

                    # Marginal contribution
                    p_with = self._predict_wrapper(v_with[np.newaxis, :], target_head=target_head)[0]
                    p_without = self._predict_wrapper(v_without[np.newaxis, :], target_head=target_head)[0]
                    phi_f += (p_with - p_without)

                shap_values[s_idx, f_idx] = phi_f / num_monte_carlo

        return shap_values, float(base_value)

    def explain_dataset(self, background_data: np.ndarray,
                        instances: np.ndarray,
                        target_head: str = 'bw') -> Dict[str, Any]:
        """
        Computes SHAP explanations and generates summary metrics.
        """
        if SHAP_AVAILABLE:
            try:
                # Use shap.KernelExplainer
                pred_fn = lambda x: self._predict_wrapper(x, target_head=target_head)
                explainer = shap.KernelExplainer(pred_fn, background_data[:20])
                shap_vals = explainer.shap_values(instances, nsamples=50)
                if isinstance(shap_vals, list):
                    shap_vals = shap_vals[0]
                base_val = explainer.expected_value
                if isinstance(base_val, (list, np.ndarray)):
                    base_val = float(base_val[0])
            except Exception:
                shap_vals, base_val = self.compute_shapley_values_native(
                    background_data, instances, target_head=target_head
                )
        else:
            shap_vals, base_val = self.compute_shapley_values_native(
                background_data, instances, target_head=target_head
            )

        # Global feature importance: mean absolute SHAP value
        global_importance = np.mean(np.abs(shap_vals), axis=0)
        sorted_indices = np.argsort(-global_importance)

        importance_df = pd.DataFrame({
            'Feature': [self.feature_names[i] for i in sorted_indices],
            'Mean_Abs_SHAP': global_importance[sorted_indices]
        })

        return {
            'shap_values': shap_vals,
            'base_value': float(base_val),
            'feature_importance_df': importance_df,
            'feature_names': self.feature_names
        }

    def generate_local_explanation_report(self, instance: np.ndarray,
                                         shap_row: np.ndarray,
                                         device_id: int,
                                         slice_name: str,
                                         target_head: str = 'Bandwidth') -> str:
        """
        Generates a human-readable interpretability report for an individual IoT device.
        """
        sorted_indices = np.argsort(-np.abs(shap_row))
        report = []
        report.append(f"--- 6G-IoTMesh Decision Explanation for Device {device_id} ({slice_name}) ---")
        report.append(f"Target Resource Allocation Decision: {target_head}")
        report.append("Top Influential Features on Policy Decision:")
        
        for rank, idx in enumerate(sorted_indices[:5], 1):
            feat = self.feature_names[idx]
            val = instance[idx]
            contrib = shap_row[idx]
            direction = "INCREASED" if contrib > 0 else "DECREASED"
            report.append(f"  {rank}. {feat} (Value={val:.3f}): {direction} allocation by {abs(contrib):.4f}")

        return "\n".join(report)
