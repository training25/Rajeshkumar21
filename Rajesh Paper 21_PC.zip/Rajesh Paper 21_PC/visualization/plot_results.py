"""
Publication-Quality Visualization Suite for 6G-IoTMesh.
Generates comprehensive figures:
- 15-Metric Comparative Bar Charts
- DRL Convergence Trajectory
- Latency and Throughput Cumulative Distribution Functions (CDFs)
- SHAP Feature Importance and Interpretability Visualizations
- Elastic Slice Reconfiguration Dynamics
"""

import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg') # Headless backend for robust plotting
import matplotlib.pyplot as plt
from typing import Dict, List, Any


class Visualizer:
    """
    Renders and exports research plots to disk.
    """
    def __init__(self, output_dir: str = "output_figures"):
        self.output_dir = output_dir
        os.makedirs(self.output_dir, exist_ok=True)
        # Publication styling
        plt.rcParams.update({
            'font.size': 11,
            'axes.labelsize': 12,
            'axes.titlesize': 13,
            'xtick.labelsize': 10,
            'ytick.labelsize': 10,
            'legend.fontsize': 10,
            'figure.titlesize': 14,
            'grid.alpha': 0.35,
            'grid.linestyle': '--'
        })
        self.colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd']

    def plot_metric_bars(self, summary_df: pd.DataFrame, filename: str = "all_15_metrics_comparison.png"):
        """
        Creates a multi-panel figure displaying all 15 metrics across evaluated algorithms.
        """
        fig, axes = plt.subplots(5, 3, figsize=(18, 22))
        axes = axes.flatten()

        metrics = list(summary_df.index)
        algos = list(summary_df.columns)
        x = np.arange(len(algos))
        width = 0.55

        titles = {
            "spectral_efficiency": "1. Spectral Efficiency (bps/Hz)",
            "network_throughput": "2. Network Throughput (Mbps)",
            "end_to_end_latency": "3. End-to-End Latency (ms) [Lower is Better]",
            "packet_delivery_ratio": "4. Packet Delivery Ratio (PDR %)",
            "energy_efficiency": "5. Energy Efficiency (Mbits/Joule)",
            "resource_utilization": "6. Resource Utilization (%)",
            "bandwidth_utilization": "7. Bandwidth Utilization (%)",
            "qos_satisfaction_rate": "8. QoS Satisfaction Rate (%)",
            "packet_loss_rate": "9. Packet Loss Rate (%) [Lower is Better]",
            "jains_fairness_index": "10. Jain's Fairness Index",
            "blocking_probability": "11. Blocking Probability (%) [Lower is Better]",
            "handover_success_rate": "12. Handover Success Rate (%)",
            "convergence_time": "13. Convergence Time (Episodes)",
            "cumulative_reward": "14. Cumulative Reward",
            "resource_allocation_overhead": "15. Allocation Overhead (ms) [Lower is Better]"
        }

        for i, m in enumerate(metrics):
            if i >= len(axes):
                break
            ax = axes[i]
            vals = summary_df.loc[m].values
            bars = ax.bar(x, vals, width, color=self.colors[:len(algos)], edgecolor='black', linewidth=0.8)
            ax.set_title(titles.get(m, m), fontweight='bold')
            ax.set_xticks(x)
            ax.set_xticklabels(algos, rotation=15, ha='right')
            ax.grid(True)

            # Value labels on bars
            for bar in bars:
                height = bar.get_height()
                ax.annotate(f'{height:.2f}',
                            xy=(bar.get_x() + bar.get_width() / 2, height),
                            xytext=(0, 3), textcoords="offset points",
                            ha='center', va='bottom', fontsize=8, fontweight='bold')

        plt.tight_layout()
        save_path = os.path.join(self.output_dir, filename)
        plt.savefig(save_path, dpi=300)
        plt.close()
        print(f"[+] Saved 15-metric comparison figure to: {save_path}")

    def plot_convergence(self, track_dict: Dict[str, Any], filename: str = "convergence_reward.png"):
        """Plots episode training reward trajectory showing convergence speed."""
        plt.figure(figsize=(9, 5.5))
        for idx, (name, tracker) in enumerate(track_dict.items()):
            if tracker.episode_rewards:
                rewards = tracker.episode_rewards
                # Smoothed moving average
                smoothed = pd.Series(rewards).rolling(window=3, min_periods=1).mean()
                plt.plot(rewards, alpha=0.3, color=self.colors[idx])
                plt.plot(smoothed, label=name, color=self.colors[idx], linewidth=2.2)

        plt.xlabel("Training Episode")
        plt.ylabel("Cumulative Episode Reward")
        plt.title("Reward Convergence Trajectory: FFR-PMN vs Baselines", fontweight='bold')
        plt.legend(loc='lower right')
        plt.grid(True)
        plt.tight_layout()
        save_path = os.path.join(self.output_dir, filename)
        plt.savefig(save_path, dpi=300)
        plt.close()
        print(f"[+] Saved convergence trajectory to: {save_path}")

    def plot_latency_cdf(self, track_dict: Dict[str, Any], filename: str = "latency_cdf.png"):
        """Plots empirical Cumulative Distribution Function (CDF) for End-to-End Latency."""
        plt.figure(figsize=(8.5, 5))
        for idx, (name, tracker) in enumerate(track_dict.items()):
            df = tracker.get_dataframe()
            if not df.empty and "end_to_end_latency" in df.columns:
                latencies = np.sort(df["end_to_end_latency"].values)
                cdf = np.arange(1, len(latencies) + 1) / len(latencies)
                plt.plot(latencies, cdf, label=name, color=self.colors[idx], linewidth=2.0)

        # 6G Tactile SLA deadline line
        plt.axvline(x=3.0, color='red', linestyle='--', linewidth=1.5, label='Tactile SLA (3.0 ms)')
        plt.xlabel("End-to-End Latency (ms)")
        plt.ylabel("Empirical CDF")
        plt.title("Cumulative Distribution Function (CDF) of End-to-End Latency", fontweight='bold')
        plt.legend(loc='lower right')
        plt.grid(True)
        plt.tight_layout()
        save_path = os.path.join(self.output_dir, filename)
        plt.savefig(save_path, dpi=300)
        plt.close()
        print(f"[+] Saved latency CDF to: {save_path}")

    def plot_shap_summary(self, importance_df: pd.DataFrame, filename: str = "shap_feature_importance.png"):
        """Plots SHAP feature attribution bar chart."""
        plt.figure(figsize=(10, 6.5))
        top_df = importance_df.head(10).iloc[::-1] # Top 10 features reversed for horizontal bars
        
        y_pos = np.arange(len(top_df))
        plt.barh(y_pos, top_df['Mean_Abs_SHAP'], color='#2b5c8f', edgecolor='black', height=0.65)
        plt.yticks(y_pos, top_df['Feature'])
        plt.xlabel("Mean |SHAP Value| (Impact on Resource Allocation Policy)")
        plt.title("SHAP Global Feature Importance for 6G-IoTMesh Elastic Allocation", fontweight='bold')
        plt.grid(True, axis='x')
        plt.tight_layout()
        save_path = os.path.join(self.output_dir, filename)
        plt.savefig(save_path, dpi=300)
        plt.close()
        print(f"[+] Saved SHAP feature importance plot to: {save_path}")
