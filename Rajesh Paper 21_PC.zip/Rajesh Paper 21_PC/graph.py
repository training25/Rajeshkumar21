# -*- coding: utf-8 -*-
"""
Created on Tue Oct 27 09:42:05 2026

@author: ADMIN
"""

#!/usr/bin/env python3
"""
Generate 15 separate bar graphs
- Times New Roman (Liberation Serif), bold, fontsize 18
- Y-axis label present
- No title
- No value labels on bars
- No rotation on x-axis labels
"""

import matplotlib.pyplot as plt
import matplotlib
import numpy as np
import os

# Use Liberation Serif as Times New Roman substitute
matplotlib.rcParams['font.family'] = 'Liberation Serif'
matplotlib.rcParams['font.weight'] = 'bold'
matplotlib.rcParams['font.size'] = 18
matplotlib.rcParams['axes.labelsize'] = 18
matplotlib.rcParams['xtick.labelsize'] = 16
matplotlib.rcParams['ytick.labelsize'] = 16
matplotlib.rcParams['axes.labelweight'] = 'bold'

# Data
metrics = [
    {"ylabel": "Spectral Efficiency (bps/Hz)",       "values": [0.35, 0.35, 0.27],     "filename": "01_spectral_efficiency.png"},
    {"ylabel": "Network Throughput (Mbps)",          "values": [34.84, 35.05, 27.32],   "filename": "02_network_throughput.png"},
    {"ylabel": "End-to-End Latency (ms)",            "values": [0.00, 0.01, 0.31],      "filename": "03_end_to_end_latency.png"},
    {"ylabel": "Packet Delivery Ratio (PDR %)",      "values": [39.50, 35.18, 20.88],   "filename": "04_packet_delivery_ratio.png"},
    {"ylabel": "Energy Efficiency (Mbits/Joule)",    "values": [1.49, 1.59, 0.38],      "filename": "05_energy_efficiency.png"},
    {"ylabel": "Resource Utilization (%)",           "values": [35.57, 35.96, 43.15],   "filename": "06_resource_utilization.png"},
    {"ylabel": "Bandwidth Utilization (%)",          "values": [22.76, 23.02, 27.62],   "filename": "07_bandwidth_utilization.png"},
    {"ylabel": "QoS Satisfaction Rate (%)",          "values": [25.95, 24.23, 24.13],   "filename": "08_qos_satisfaction_rate.png"},
    {"ylabel": "Packet Loss Rate (%)",               "values": [84.57, 89.43, 121.19],  "filename": "09_packet_loss_rate.png"},
    {"ylabel": "Jain's Fairness Index",              "values": [0.17, 0.16, 0.20],      "filename": "10_jains_fairness_index.png"},
    {"ylabel": "Blocking Probability (%)",           "values": [3.52, 4.38, 2.88],      "filename": "11_blocking_probability.png"},
    {"ylabel": "Handover Success Rate (%)",          "values": [100.00, 100.00, 100.00],"filename": "12_handover_success_rate.png"},
    {"ylabel": "Convergence Time (Episodes)",        "values": [10.00, 10.00, 10.00],   "filename": "13_convergence_time.png"},
    {"ylabel": "Cumulative Reward",                  "values": [-537.56, -563.16, -1540.01], "filename": "14_cumulative_reward.png"},
    {"ylabel": "Allocation Overhead (ms)",           "values": [299.78, 144.29, 122.96],"filename": "15_allocation_overhead.png"},
]

labels = ["FFR-PMN\n(Proposed)", "Standard\nDRL", "Static\nSlicing"]
colors = ["#1f77b4", "#ff7f0e", "#2ca02c"]  # Blue, Orange, Green

output_dir = "separate_graphs"
os.makedirs(output_dir, exist_ok=True)

for metric in metrics:
    fig, ax = plt.subplots(figsize=(8, 6))
    
    x = np.arange(len(labels))
    ax.bar(x, metric["values"], color=colors, edgecolor="black", linewidth=0.8, width=0.6)
    
    # Y-axis limits with padding
    vals = metric["values"]
    ymin = min(0, min(vals))
    ymax = max(0, max(vals))
    yrange = ymax - ymin if ymax != ymin else 1.0
    padding = yrange * 0.15
    if ymin < 0:
        ax.set_ylim(ymin - padding * 0.5, ymax + padding * 0.3)
    else:
        ax.set_ylim(0, ymax + padding)
    
    # X-axis (no rotation)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontweight="bold", fontsize=16, fontfamily="Liberation Serif")
    
    # Y-axis label
    ax.set_ylabel(metric["ylabel"], fontweight="bold", fontsize=18, fontfamily="Liberation Serif")
    
    # Grid
    ax.yaxis.grid(True, linestyle="--", alpha=0.7)
    ax.set_axisbelow(True)
    
    # Spines
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    
    # Make y-tick labels bold
    for label in ax.get_yticklabels():
        label.set_fontweight("bold")
        label.set_fontsize(16)
        label.set_fontfamily("Liberation Serif")
    
    plt.tight_layout()
    
    out_path = os.path.join(output_dir, metric["filename"])
    plt.savefig(out_path, dpi=200, bbox_inches="tight", facecolor="white")
    plt.close()
    print(f"Saved: {out_path}")

print(f"\nAll 15 graphs saved to {output_dir}/")



#!/usr/bin/env python3
"""
Recreate SHAP Feature Importance and Reward Convergence plots
with Times New Roman (Liberation Serif), bold, fontsize 18
"""

import matplotlib.pyplot as plt
import matplotlib
import numpy as np
import os

# Font settings
matplotlib.rcParams['font.family'] = 'Liberation Serif'
matplotlib.rcParams['font.weight'] = 'bold'
matplotlib.rcParams['font.size'] = 18
matplotlib.rcParams['axes.titlesize'] = 18
matplotlib.rcParams['axes.labelsize'] = 18
matplotlib.rcParams['xtick.labelsize'] = 16
matplotlib.rcParams['ytick.labelsize'] = 16
matplotlib.rcParams['legend.fontsize'] = 16
matplotlib.rcParams['axes.titleweight'] = 'bold'
matplotlib.rcParams['axes.labelweight'] = 'bold'

output_dir = "recreated_plots"
os.makedirs(output_dir, exist_ok=True)

# ============================================================
# 1. SHAP Global Feature Importance (Horizontal Bar)
# ============================================================
features = [
    "Slice_ID",
    "Target_Reliability",
    "Tactile_Indicator",
    "Latency_Deadline_ms",
    "Slice_PRB_Availability",
    "Computation_Demand_Gcyc",
    "Mesh_Router_Dist_m",
    "Spatial_Density_Index",
    "Content_Size_kB",
    "Queue_Backlog_pkts",
]

shap_values = [
    0.00225,
    0.00055,
    0.00052,
    0.00042,
    0.00022,
    0.00012,
    0.00011,
    0.00007,
    0.00004,
    0.000015,
]

fig, ax = plt.subplots(figsize=(12, 8))

y_pos = np.arange(len(features))
ax.barh(y_pos, shap_values, color="#1f77b4", edgecolor="black", linewidth=0.6, height=0.65)

ax.set_yticks(y_pos)
ax.set_yticklabels(features, fontweight="bold", fontsize=16, fontfamily="Liberation Serif")
ax.invert_yaxis()  # highest at top

ax.set_xlabel("Mean |SHAP Value| (Impact on Resource Allocation Policy)",
              fontweight="bold", fontsize=18, fontfamily="Liberation Serif")
ax.set_title("SHAP Global Feature Importance for 6G-IoTMesh Elastic Allocation",
             fontweight="bold", fontsize=18, fontfamily="Liberation Serif", pad=15)

ax.set_xlim(0, 0.0025)
ax.xaxis.grid(True, linestyle="--", alpha=0.6)
ax.set_axisbelow(True)
ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)

for label in ax.get_xticklabels():
    label.set_fontweight("bold")
    label.set_fontsize(16)
    label.set_fontfamily("Liberation Serif")

plt.tight_layout()
plt.savefig(os.path.join(output_dir, "shap_feature_importance.png"), dpi=200, bbox_inches="tight", facecolor="white")
plt.close()
print("Saved: shap_feature_importance.png")

# ============================================================
# 2. Reward Convergence Trajectory
# ============================================================
episodes = np.arange(0, 12)

# Approximate trajectories (replace with your exact data if available)
ffr_pmn = np.array([-36.5, -40.5, -41.0, -42.0, -44.5, -45.0, -46.5, -45.0, -43.5, -43.0, -44.5, -46.0])
std_drl = np.array([-40.0, -44.0, -46.5, -45.0, -47.0, -45.5, -46.0, -47.5, -49.0, -48.0, -48.5, -48.0])
static  = np.array([-115.0, -126.0, -129.0, -132.0, -131.0, -130.5, -131.0, -130.0, -128.0, -123.5, -125.0, -127.0])

# Light background lines (to mimic original style)
ffr_light    = ffr_pmn + np.array([0, -2, 1, 0.5, -1, 2, -1.5, 1, 0.5, -0.5, 0, 0.5])
std_light    = std_drl + np.array([1, -1, -2, 3, -3, 1.5, -0.5, -2, 1, -1, 0.5, -1])
static_light = static  + np.array([1, -3, -2, 1, 0.5, -0.5, 1, 2, 1.5, 3, -2, -1])

fig, ax = plt.subplots(figsize=(11, 7))

# Background lines
ax.plot(episodes, ffr_light,    color="#1f77b4", alpha=0.35, linewidth=1.8)
ax.plot(episodes, std_light,    color="#ff7f0e", alpha=0.35, linewidth=1.8)
ax.plot(episodes, static_light, color="#2ca02c", alpha=0.35, linewidth=1.8)

# Main lines
ax.plot(episodes, ffr_pmn, color="#1f77b4", linewidth=2.5, label="FFR-PMN (Proposed)")
ax.plot(episodes, std_drl, color="#ff7f0e", linewidth=2.5, label="Standard DRL")
ax.plot(episodes, static,  color="#2ca02c", linewidth=2.5, label="Static Slicing")

ax.set_xlabel("Training Episode", fontweight="bold", fontsize=18, fontfamily="Liberation Serif")
ax.set_ylabel("Cumulative Episode Reward", fontweight="bold", fontsize=18, fontfamily="Liberation Serif")
ax.set_title("Reward Convergence Trajectory: FFR-PMN vs Baselines",
             fontweight="bold", fontsize=18, fontfamily="Liberation Serif", pad=12)

ax.set_xlim(0, 11)
ax.set_ylim(-145, -30)
ax.set_xticks(np.arange(0, 12, 2))

ax.yaxis.grid(True, linestyle="--", alpha=0.6)
ax.xaxis.grid(True, linestyle="--", alpha=0.4)
ax.set_axisbelow(True)
ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)

ax.legend(loc="lower right", frameon=True, fancybox=False, edgecolor="black",
          prop={'family': 'Liberation Serif', 'weight': 'bold', 'size': 15})

for label in ax.get_xticklabels() + ax.get_yticklabels():
    label.set_fontweight("bold")
    label.set_fontsize(16)
    label.set_fontfamily("Liberation Serif")

plt.tight_layout()
plt.savefig(os.path.join(output_dir, "convergence_reward.png"), dpi=200, bbox_inches="tight", facecolor="white")
plt.close()
print("Saved: convergence_reward.png")