"""
6G Dynamic Network Slicing Manager with Closed-Loop Feedback Control.
Handles elastic bandwidth and PRB reallocation between Tactile-URLLC,
eMBB, and mMTC slices based on real-time SLA feedback.
"""

import numpy as np
from typing import Dict, List
from .iot_device import DeviceType, IoTDevice


class NetworkSlice:
    """Represents a virtualized 6G network slice partition."""
    def __init__(self, slice_id: int, name: str, prb_share: float,
                 total_prbs: int, total_bw_hz: float, max_latency_ms: float,
                 target_reliability: float):
        self.slice_id = slice_id
        self.name = name
        self.prb_share = prb_share
        self.total_prbs = total_prbs
        self.total_bw_hz = total_bw_hz
        self.max_latency_ms = max_latency_ms
        self.target_reliability = target_reliability

        # Dynamic state
        self.allocated_prbs = int(np.round(prb_share * total_prbs))
        self.allocated_bw_hz = (self.allocated_prbs / total_prbs) * total_bw_hz
        self.active_devices: List[int] = []
        self.current_latency_ms = 0.0
        self.current_pdr = 1.0
        self.sla_violations = 0
        self.total_transmissions = 0

    def update_allocation(self, new_prb_count: int, total_prbs: int, total_bw_hz: float):
        self.allocated_prbs = max(1, min(new_prb_count, total_prbs))
        self.prb_share = self.allocated_prbs / total_prbs
        self.allocated_bw_hz = self.prb_share * total_bw_hz


class SliceManager:
    """
    Manages dynamic slice partitioning and closed-loop feedback adaptation
    for tactile signal surges and varying IoT traffic.
    """
    def __init__(self, config: dict):
        self.config = config
        self.total_prbs = config['network']['num_prbs']
        self.total_bw_hz = config['network']['total_bandwidth_mhz'] * 1e6
        self.feedback_enabled = config['closed_loop_feedback']['enabled']
        self.latency_thresh_ms = config['closed_loop_feedback']['latency_violation_threshold_ms']
        self.pdr_thresh = config['closed_loop_feedback']['pdr_violation_threshold']
        self.borrow_step = config['closed_loop_feedback']['elastic_borrow_step_ratio']
        self.min_share = config['closed_loop_feedback']['min_slice_prb_share']
        self.cooldown_slots = config['closed_loop_feedback']['cooldown_slots']
        self.cooldown_counter = 0

        # Initialize the 3 slices
        t_cfg = config['traffic_slices']['tactile_urllc']
        e_cfg = config['traffic_slices']['embb']
        m_cfg = config['traffic_slices']['mmtc']

        self.slices: Dict[DeviceType, NetworkSlice] = {
            DeviceType.TACTILE_URLLC: NetworkSlice(
                slice_id=0, name=t_cfg['name'], prb_share=t_cfg['initial_prb_share'],
                total_prbs=self.total_prbs, total_bw_hz=self.total_bw_hz,
                max_latency_ms=t_cfg['max_latency_deadline_ms'],
                target_reliability=t_cfg['target_reliability']
            ),
            DeviceType.EMBB: NetworkSlice(
                slice_id=1, name=e_cfg['name'], prb_share=e_cfg['initial_prb_share'],
                total_prbs=self.total_prbs, total_bw_hz=self.total_bw_hz,
                max_latency_ms=e_cfg['max_latency_deadline_ms'],
                target_reliability=e_cfg['target_reliability']
            ),
            DeviceType.MMTC: NetworkSlice(
                slice_id=2, name=m_cfg['name'], prb_share=m_cfg['initial_prb_share'],
                total_prbs=self.total_prbs, total_bw_hz=self.total_bw_hz,
                max_latency_ms=m_cfg['max_latency_deadline_ms'],
                target_reliability=m_cfg['target_reliability']
            )
        }
        self._normalize_prb_distribution()

    def _normalize_prb_distribution(self):
        """Ensures sum of allocated PRBs equals total_prbs exactly."""
        prbs = [s.allocated_prbs for s in self.slices.values()]
        diff = self.total_prbs - sum(prbs)
        if diff != 0:
            # Distribute diff to eMBB or mMTC
            self.slices[DeviceType.EMBB].allocated_prbs += diff
            for s in self.slices.values():
                s.update_allocation(s.allocated_prbs, self.total_prbs, self.total_bw_hz)

    def register_device(self, device: IoTDevice):
        """Associates a device to its respective slice."""
        self.slices[device.device_type].active_devices.append(device.device_id)

    def execute_closed_loop_reconfiguration(self, tactile_mean_latency_ms: float,
                                           tactile_pdr: float) -> bool:
        """
        Closed-loop feedback engine:
        Detects SLA violations in the Tactile slice and dynamically borrows
        PRBs from eMBB or mMTC slices to guarantee tactile deadlines.
        """
        if not self.feedback_enabled:
            return False

        if self.cooldown_counter > 0:
            self.cooldown_counter -= 1
            return False

        reconfigured = False
        tactile_slice = self.slices[DeviceType.TACTILE_URLLC]
        embb_slice = self.slices[DeviceType.EMBB]
        mmtc_slice = self.slices[DeviceType.MMTC]

        tactile_slice.current_latency_ms = tactile_mean_latency_ms
        tactile_slice.current_pdr = tactile_pdr

        # Condition 1: Tactile SLA violated -> Elastic expansion
        if tactile_mean_latency_ms > self.latency_thresh_ms or tactile_pdr < self.pdr_thresh:
            prbs_to_borrow = int(np.ceil(self.borrow_step * self.total_prbs))
            
            # Check if eMBB and mMTC have PRBs above minimum floor
            min_prbs = int(self.min_share * self.total_prbs)
            borrowable_embb = max(0, embb_slice.allocated_prbs - min_prbs)
            borrowable_mmtc = max(0, mmtc_slice.allocated_prbs - min_prbs)
            
            if borrowable_embb + borrowable_mmtc >= prbs_to_borrow:
                # Borrow proportionally
                embb_deduct = min(borrowable_embb, int(np.ceil(prbs_to_borrow * 0.6)))
                mmtc_deduct = min(borrowable_mmtc, prbs_to_borrow - embb_deduct)
                
                embb_slice.update_allocation(embb_slice.allocated_prbs - embb_deduct,
                                             self.total_prbs, self.total_bw_hz)
                mmtc_slice.update_allocation(mmtc_slice.allocated_prbs - mmtc_deduct,
                                             self.total_prbs, self.total_bw_hz)
                tactile_slice.update_allocation(tactile_slice.allocated_prbs + embb_deduct + mmtc_deduct,
                                                self.total_prbs, self.total_bw_hz)
                
                tactile_slice.sla_violations += 1
                self.cooldown_counter = self.cooldown_slots
                reconfigured = True

        # Condition 2: Tactile well below SLA threshold -> Elastic relaxation
        elif tactile_mean_latency_ms < (self.latency_thresh_ms * 0.5) and tactile_pdr > 0.999:
            initial_tactile_prbs = int(self.config['traffic_slices']['tactile_urllc']['initial_prb_share'] * self.total_prbs)
            if tactile_slice.allocated_prbs > initial_tactile_prbs:
                return_prbs = min(tactile_slice.allocated_prbs - initial_tactile_prbs, 2)
                tactile_slice.update_allocation(tactile_slice.allocated_prbs - return_prbs,
                                                self.total_prbs, self.total_bw_hz)
                embb_slice.update_allocation(embb_slice.allocated_prbs + return_prbs,
                                             self.total_prbs, self.total_bw_hz)
                self.cooldown_counter = self.cooldown_slots
                reconfigured = True

        return reconfigured

    def get_slice_prb_bandwidth(self, device_type: DeviceType) -> tuple:
        """Returns (allocated_prbs, allocated_bandwidth_hz) for the specified slice."""
        s = self.slices[device_type]
        return s.allocated_prbs, s.allocated_bw_hz
