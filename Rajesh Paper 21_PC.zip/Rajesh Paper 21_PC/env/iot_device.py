"""
6G Massive IoT Device Representation and Traffic Generator.
Models heterogeneous IoT devices: Tactile-URLLC, eMBB, and mMTC,
including queue dynamics, battery depletion, edge computation offloading,
and mobility within the 6G mesh coverage.
"""

import enum
import numpy as np
from typing import List, Optional


class DeviceType(enum.IntEnum):
    TACTILE_URLLC = 0
    EMBB = 1
    MMTC = 2


class Packet:
    """Represents a data packet with in-content metadata."""
    def __init__(self, packet_id: int, device_id: int, arrival_time_ms: float,
                 size_bytes: int, latency_deadline_ms: float,
                 target_reliability: float, content_type: DeviceType,
                 is_tactile: bool, computation_cycles: float):
        self.packet_id = packet_id
        self.device_id = device_id
        self.arrival_time_ms = arrival_time_ms
        self.size_bytes = size_bytes
        self.latency_deadline_ms = latency_deadline_ms
        self.target_reliability = target_reliability
        self.content_type = content_type
        self.is_tactile = is_tactile
        self.computation_cycles = computation_cycles
        self.age_ms = 0.0
        self.transmitted_bytes = 0

    @property
    def remaining_bytes(self) -> int:
        return max(0, self.size_bytes - self.transmitted_bytes)

    @property
    def is_fully_transmitted(self) -> bool:
        return self.remaining_bytes == 0

    def is_expired(self, current_time_ms: float) -> bool:
        return (current_time_ms - self.arrival_time_ms) > self.latency_deadline_ms


class IoTDevice:
    """
    Simulates an individual 6G IoT Node in the massive mesh deployment.
    """
    def __init__(self, device_id: int, device_type: DeviceType,
                 initial_position: np.ndarray, config: dict):
        self.device_id = device_id
        self.device_type = device_type
        self.position = np.array(initial_position, dtype=float)
        self.velocity = np.zeros(3, dtype=float)
        self.config = config

        # Specs
        self.max_tx_power_dbm = config['device_specs']['max_tx_power_dbm']
        self.min_tx_power_dbm = config['device_specs']['min_tx_power_dbm']
        self.battery_capacity_joules = config['device_specs']['initial_battery_joules']
        self.residual_battery_joules = self.battery_capacity_joules
        self.circuit_power_w = config['device_specs']['circuit_power_mw'] * 1e-3
        self.local_cpu_freq_hz = config['device_specs']['local_cpu_freq_ghz'] * 1e9
        self.cycles_per_bit = config['device_specs']['cycles_per_bit']
        self.max_queue_size = config['device_specs']['max_queue_size_packets']
        self.max_speed_mps = config['device_specs']['mobility_speed_max_mps']

        # Slicing & Association
        self.associated_router_id = 0
        self.handover_count = 0
        self.handover_attempts = 0

        # Queues & Packet Tracker
        self.queue: List[Packet] = []
        self.packet_counter = 0
        self.total_packets_generated = 0
        self.total_packets_delivered = 0
        self.total_packets_dropped = 0
        self.total_bits_delivered = 0
        self.total_energy_consumed_joules = 0.0

        # Chip capacitance coefficient for local CPU energy: E = kappa * f^2 * cycles
        self.cpu_kappa = 1e-28

        # Cache last state
        self.last_sinr_db = 0.0
        self.last_path_loss_db = 80.0
        self.last_allocated_bw_hz = 0.0
        self.last_tx_power_w = 0.0

    def update_mobility(self, time_step_sec: float, area_limits: tuple):
        """
        Updates 3D device coordinates with boundary reflection.
        """
        # Random Waypoint / Gauss-Markov velocity update
        if np.random.rand() < 0.2:
            speed = np.random.uniform(0.0, self.max_speed_mps)
            theta = np.random.uniform(0, 2 * np.pi)
            phi = np.random.uniform(-0.1, 0.1) # low vertical movement
            self.velocity = np.array([
                speed * np.cos(theta),
                speed * np.sin(theta),
                speed * np.sin(phi)
            ])

        new_pos = self.position + self.velocity * time_step_sec

        # Boundary checks [0, W], [0, H], [1.0, D]
        w, h, d = area_limits
        for i, limit in enumerate([w, h, d]):
            if new_pos[i] < 0.0:
                new_pos[i] = -new_pos[i]
                self.velocity[i] = -self.velocity[i]
            elif new_pos[i] > limit:
                new_pos[i] = 2 * limit - new_pos[i]
                self.velocity[i] = -self.velocity[i]
        
        self.position = new_pos

    def generate_traffic(self, current_time_ms: float):
        """
        Generates in-content aware packets according to slice characteristics.
        """
        slice_cfg = None
        if self.device_type == DeviceType.TACTILE_URLLC:
            slice_cfg = self.config['traffic_slices']['tactile_urllc']
        elif self.device_type == DeviceType.EMBB:
            slice_cfg = self.config['traffic_slices']['embb']
        else:
            slice_cfg = self.config['traffic_slices']['mmtc']

        # Determine burst or periodic arrival
        burst_prob = slice_cfg['burst_probability']
        mean_size = slice_cfg['packet_size_bytes_mean']
        arrival_trigger = (np.random.rand() < burst_prob)

        if arrival_trigger:
            self.packet_counter += 1
            self.total_packets_generated += 1
            
            # Content-aware size variance
            if self.device_type == DeviceType.TACTILE_URLLC:
                size_bytes = int(np.random.normal(mean_size, 64))
                size_bytes = max(128, min(size_bytes, 1024))
                is_tactile = True
                deadline = slice_cfg['max_latency_deadline_ms']
                reliability = slice_cfg['target_reliability']
            elif self.device_type == DeviceType.EMBB:
                size_bytes = int(np.random.lognormal(mean=np.log(mean_size), sigma=0.4))
                size_bytes = max(10240, min(size_bytes, 262144))
                is_tactile = False
                deadline = slice_cfg['max_latency_deadline_ms']
                reliability = slice_cfg['target_reliability']
            else: # MMTC
                size_bytes = int(np.random.exponential(scale=mean_size))
                size_bytes = max(64, min(size_bytes, 1024))
                is_tactile = False
                deadline = slice_cfg['max_latency_deadline_ms']
                reliability = slice_cfg['target_reliability']

            comp_cycles = size_bytes * 8 * self.cycles_per_bit

            pkt = Packet(
                packet_id=self.packet_counter,
                device_id=self.device_id,
                arrival_time_ms=current_time_ms,
                size_bytes=size_bytes,
                latency_deadline_ms=deadline,
                target_reliability=reliability,
                content_type=self.device_type,
                is_tactile=is_tactile,
                computation_cycles=comp_cycles
            )

            # Check queue capacity
            if len(self.queue) < self.max_queue_size:
                self.queue.append(pkt)
            else:
                # Buffer overflow drop
                self.total_packets_dropped += 1

    def purge_expired_packets(self, current_time_ms: float) -> int:
        """Removes packets that exceeded latency deadline (SLA violation drop)."""
        initial_len = len(self.queue)
        valid_queue = []
        for pkt in self.queue:
            if not pkt.is_expired(current_time_ms):
                pkt.age_ms = current_time_ms - pkt.arrival_time_ms
                valid_queue.append(pkt)
            else:
                self.total_packets_dropped += 1

        self.queue = valid_queue
        dropped_count = initial_len - len(self.queue)
        return dropped_count

    def consume_energy(self, tx_power_w: float, duration_sec: float,
                       computed_cycles_local: float = 0.0) -> float:
        """
        Drains battery based on RF transmission, baseline circuit power,
        and local CPU computational processing.
        """
        tx_energy = tx_power_w * duration_sec
        circuit_energy = self.circuit_power_w * duration_sec
        comp_energy = self.cpu_kappa * (self.local_cpu_freq_hz ** 2) * computed_cycles_local
        
        total_energy = tx_energy + circuit_energy + comp_energy
        self.residual_battery_joules = max(0.0, self.residual_battery_joules - total_energy)
        self.total_energy_consumed_joules += total_energy
        return total_energy

    @property
    def residual_battery_ratio(self) -> float:
        return self.residual_battery_joules / (self.battery_capacity_joules + 1e-9)

    @property
    def queue_delay_ms(self) -> float:
        if not self.queue:
            return 0.0
        return float(self.queue[0].age_ms)

    @property
    def queue_backlog_bits(self) -> int:
        return sum(pkt.remaining_bytes * 8 for pkt in self.queue)
