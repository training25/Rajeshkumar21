"""
6G-IoTMesh Simulation Environment.
Gymnasium-compatible environment modeling massive IoT mesh networks,
in-content-aware traffic, dynamic network slicing, 6G physical channels,
edge computing offloading, and multi-objective performance tracking.
"""

import copy
import yaml
import numpy as np
from typing import Dict, List, Tuple, Any

from .channel_model import Channel6G
from .iot_device import IoTDevice, DeviceType, Packet
from .slice_manager import SliceManager


class IoTMeshEnv:
    """
    Simulates a 6G massive IoT mesh network with multi-cluster edge orchestration.
    """
    def __init__(self, config_path: str = None, config_dict: dict = None):
        if config_dict is not None:
            self.config = config_dict
        elif config_path is not None:
            with open(config_path, 'r') as f:
                self.config = yaml.safe_load(f)
        else:
            raise ValueError("Either config_path or config_dict must be provided.")

        self.net_cfg = self.config['network']
        self.width = self.net_cfg['area_width']
        self.height = self.net_cfg['area_height']
        self.depth = self.net_cfg['area_depth']
        self.num_routers = self.net_cfg['num_mesh_routers']
        self.num_devices = self.net_cfg['num_devices']
        self.num_prbs = self.net_cfg['num_prbs']
        self.total_bw_hz = self.net_cfg['total_bandwidth_mhz'] * 1e6
        self.prb_bw_hz = self.total_bw_hz / self.num_prbs

        # Edge Computing Specs
        self.edge_cpu_total_ghz = self.config['device_specs']['edge_server_cpu_freq_ghz']
        self.edge_cpu_available_hz = self.edge_cpu_total_ghz * 1e9

        # Physical Channel & Slicing
        self.channel = Channel6G(
            carrier_frequency_ghz=self.net_cfg['carrier_frequency_ghz'],
            total_bandwidth_mhz=self.net_cfg['total_bandwidth_mhz'],
            noise_figure_db=self.net_cfg['noise_figure_db'],
            noise_psd_dbm=self.net_cfg['noise_power_spectral_density_dbm']
        )
        self.slice_mgr = SliceManager(self.config)

        # Deploy 6G Mesh Routers / Cluster Heads (CH)
        self.router_positions = self._deploy_mesh_routers()

        # Deploy IoT Devices
        self.devices: List[IoTDevice] = []
        self._deploy_iot_devices()

        # Spatio-Temporal History buffer
        self.temporal_window = self.config['federated_rl'].get('temporal_window_size', 5)
        self.state_dim = self.config['federated_rl'].get('state_dim', 18)
        self.state_history = np.zeros((self.num_devices, self.temporal_window, self.state_dim), dtype=np.float32)

        # Simulation clock
        self.time_step_sec = 0.01  # 10 ms time slot
        self.current_time_ms = 0.0
        self.current_step = 0
        self.max_steps = 100

        # Reward weights
        self.rw = self.config['reward_weights']

        # Handover stats
        self.total_handovers_attempted = 0
        self.total_handovers_successful = 0

    def _deploy_mesh_routers(self) -> np.ndarray:
        """Positions 6G Mesh Routers uniformly in the service area."""
        positions = []
        if self.num_routers == 4:
            xs = [self.width * 0.25, self.width * 0.75]
            ys = [self.height * 0.25, self.height * 0.75]
            for x in xs:
                for y in ys:
                    positions.append([x, y, self.depth]) # Routers on elevated poles/ceilings
        else:
            for i in range(self.num_routers):
                angle = 2 * np.pi * i / self.num_routers
                r = min(self.width, self.height) * 0.35
                x = self.width / 2 + r * np.cos(angle)
                y = self.height / 2 + r * np.sin(angle)
                positions.append([x, y, self.depth])
        return np.array(positions, dtype=float)

    def _deploy_iot_devices(self):
        """Initializes heterogeneous massive IoT devices."""
        t_ratio = self.config['traffic_slices']['tactile_urllc']['ratio_of_devices']
        e_ratio = self.config['traffic_slices']['embb']['ratio_of_devices']
        
        num_tactile = int(np.round(self.num_devices * t_ratio))
        num_embb = int(np.round(self.num_devices * e_ratio))
        num_mmtc = self.num_devices - num_tactile - num_embb

        device_types = ([DeviceType.TACTILE_URLLC] * num_tactile +
                        [DeviceType.EMBB] * num_embb +
                        [DeviceType.MMTC] * num_mmtc)
        np.random.shuffle(device_types)

        for dev_id, dtype in enumerate(device_types):
            # 3D random uniform position
            pos = np.array([
                np.random.uniform(10.0, self.width - 10.0),
                np.random.uniform(10.0, self.height - 10.0),
                np.random.uniform(1.0, 3.0) # IoT devices close to ground
            ])
            device = IoTDevice(dev_id, dtype, pos, self.config)
            
            # Associate to closest mesh router
            dists = [self.channel.compute_distance_3d(pos, r_pos) for r_pos in self.router_positions]
            device.associated_router_id = int(np.argmin(dists))
            
            self.slice_mgr.register_device(device)
            self.devices.append(device)

    def reset(self) -> np.ndarray:
        """Resets the simulation environment to initial state."""
        self.current_time_ms = 0.0
        self.current_step = 0
        self.total_handovers_attempted = 0
        self.total_handovers_successful = 0
        
        # Reset slicing
        self.slice_mgr = SliceManager(self.config)
        for dev in self.devices:
            self.slice_mgr.register_device(dev)
            dev.queue.clear()
            dev.residual_battery_joules = dev.battery_capacity_joules
            dev.total_packets_generated = 0
            dev.total_packets_delivered = 0
            dev.total_packets_dropped = 0
            dev.total_bits_delivered = 0
            dev.total_energy_consumed_joules = 0.0

        self.state_history.fill(0.0)

        # Generate initial packets and build state
        for dev in self.devices:
            dev.generate_traffic(self.current_time_ms)

        obs = self._get_normalized_states()
        for i in range(self.temporal_window):
            self.state_history[:, i, :] = obs
            
        return obs

    def _get_normalized_states(self) -> np.ndarray:
        """
        Extracts and normalizes multi-dimensional features for all IoT devices:
        1. SINR (dB normalized [-10, 35])
        2. Path Loss (dB normalized [50, 140])
        3. Queue Backlog packets ([0, 1])
        4. Queue Delay ms ([0, 1])
        5. Residual Battery Ratio ([0, 1])
        6. Packet Urgency ([0, 1])
        7. Tactile Indicator (0 or 1)
        8. Content Size kB ([0, 1])
        9. Computation Demand ([0, 1])
        10. Latency Deadline ms ([0, 1])
        11. Target Reliability ([0.9, 1.0] -> [0, 1])
        12. Router Distance ([0, 1])
        13. Interference Power ([0, 1])
        14. Slice ID normalized ([0, 1])
        15. Slice PRB Availability ratio ([0, 1])
        16. Edge CPU Load ratio ([0, 1])
        17. Channel Coherence Ratio ([0, 1])
        18. Spatial Node Density ([0, 1])
        """
        states = np.zeros((self.num_devices, self.state_dim), dtype=np.float32)
        diag = np.sqrt(self.width**2 + self.height**2 + self.depth**2)

        for i, dev in enumerate(self.devices):
            router_pos = self.router_positions[dev.associated_router_id]
            dist = self.channel.compute_distance_3d(dev.position, router_pos)
            
            # Content & Queue
            head_pkt = dev.queue[0] if dev.queue else None
            pkt_urgency = 0.0
            content_size_kb = 0.0
            comp_cycles = 0.0
            is_tactile = 1.0 if dev.device_type == DeviceType.TACTILE_URLLC else 0.0
            deadline = 50.0
            reliability = 0.95

            if head_pkt:
                pkt_urgency = min(1.0, head_pkt.age_ms / (head_pkt.latency_deadline_ms + 1e-5))
                content_size_kb = head_pkt.size_bytes / 1024.0
                comp_cycles = head_pkt.computation_cycles / 1e8
                deadline = head_pkt.latency_deadline_ms
                reliability = head_pkt.target_reliability

            # Slice info
            slice_obj = self.slice_mgr.slices[dev.device_type]
            slice_prb_ratio = slice_obj.allocated_prbs / self.num_prbs

            # Compute local spatial density (number of devices within 50m)
            neighbor_count = sum(
                1 for other in self.devices 
                if other.device_id != dev.device_id and np.linalg.norm(other.position - dev.position) < 50.0
            )
            spatial_density = min(1.0, neighbor_count / 20.0)

            states[i, 0] = np.clip((dev.last_sinr_db + 10.0) / 45.0, 0.0, 1.0)
            states[i, 1] = np.clip((dev.last_path_loss_db - 50.0) / 90.0, 0.0, 1.0)
            states[i, 2] = min(1.0, len(dev.queue) / dev.max_queue_size)
            states[i, 3] = min(1.0, dev.queue_delay_ms / 100.0)
            states[i, 4] = dev.residual_battery_ratio
            states[i, 5] = pkt_urgency
            states[i, 6] = is_tactile
            states[i, 7] = min(1.0, content_size_kb / 256.0)
            states[i, 8] = min(1.0, comp_cycles)
            states[i, 9] = min(1.0, deadline / 100.0)
            states[i, 10] = (reliability - 0.90) / 0.10
            states[i, 11] = min(1.0, dist / diag)
            states[i, 12] = 0.2 # Baseline normalized interference
            states[i, 13] = float(dev.device_type) / 2.0
            states[i, 14] = slice_prb_ratio
            states[i, 15] = 0.5 # Edge server load index
            states[i, 16] = 0.8 # Channel coherence factor
            states[i, 17] = spatial_density

        return states

    def step(self, actions: Dict[str, np.ndarray]) -> Tuple[np.ndarray, float, bool, Dict[str, Any]]:
        """
        Executes one time-step of 6G-IoTMesh:
        Actions dict contains:
        - 'ue_inclusion': binary / continuous inclusion mask (N,)
        - 'power_allocation': normalized transmit power in [0, 1] (N,)
        - 'bw_share': normalized bandwidth / PRB fraction per device (N,)
        - 'offload_ratio': computation offloading fraction in [0, 1] (N,)
        """
        self.current_step += 1
        self.current_time_ms += (self.time_step_sec * 1000.0)

        ue_inclusion = actions.get('ue_inclusion', np.ones(self.num_devices))
        power_alloc = actions.get('power_allocation', np.ones(self.num_devices) * 0.5)
        bw_share = actions.get('bw_share', np.ones(self.num_devices) / self.num_devices)
        offload_ratio = actions.get('offload_ratio', np.zeros(self.num_devices))

        # 1. Update IoT Mobility & Trigger Handover
        for dev in self.devices:
            dev.update_mobility(self.time_step_sec, (self.width, self.height, self.depth))
            self._evaluate_handover(dev)

        # 2. Traffic Generation & Queue Expiry Purging
        total_expired_packets = 0
        for dev in self.devices:
            dev.generate_traffic(self.current_time_ms)
            dropped = dev.purge_expired_packets(self.current_time_ms)
            total_expired_packets += dropped

        # 3. Determine active transmitting devices (Adaptive UE Inclusion)
        # Inclusion threshold: probability or top-K based on action
        active_indices = []
        for i, dev in enumerate(self.devices):
            if len(dev.queue) > 0 and dev.residual_battery_ratio > 0.01:
                # Include device if action >= 0.5 or tactile urgency overrides
                if ue_inclusion[i] >= 0.45 or dev.device_type == DeviceType.TACTILE_URLLC:
                    active_indices.append(i)

        # 4. Resource Allocation & Physical Layer Transmission
        slot_throughput_bits = 0.0
        slot_energy_joules = 0.0
        tactile_latencies = []
        tactile_deliveries = 0
        tactile_attempts = 0
        qos_satisfied_count = 0
        device_rates = np.zeros(self.num_devices)

        # Calculate channel gains and compute mutual interference
        active_gains = {}
        active_tx_powers_w = {}
        
        for idx in active_indices:
            dev = self.devices[idx]
            router_pos = self.router_positions[dev.associated_router_id]
            gain, pl_db, is_los = self.channel.compute_channel_gain(dev.position, router_pos)
            active_gains[idx] = gain
            dev.last_path_loss_db = pl_db

            # Power allocation in Watts
            p_min_w = 10.0 ** ((dev.min_tx_power_dbm - 30.0) / 10.0)
            p_max_w = 10.0 ** ((dev.max_tx_power_dbm - 30.0) / 10.0)
            tx_p_w = p_min_w + float(power_alloc[idx]) * (p_max_w - p_min_w)
            active_tx_powers_w[idx] = tx_p_w

        # Slice-based bandwidth sharing
        slice_active_counts = {DeviceType.TACTILE_URLLC: 0, DeviceType.EMBB: 0, DeviceType.MMTC: 0}
        for idx in active_indices:
            slice_active_counts[self.devices[idx].device_type] += 1

        # Transmit & Compute
        for idx in active_indices:
            dev = self.devices[idx]
            gain = active_gains[idx]
            tx_p_w = active_tx_powers_w[idx]

            # Slice PRB pool
            slice_obj = self.slice_mgr.slices[dev.device_type]
            slice_bw = slice_obj.allocated_bw_hz
            num_in_slice = max(1, slice_active_counts[dev.device_type])
            
            # Elastic per-device bandwidth
            allocated_bw = (slice_bw / num_in_slice) * np.clip(bw_share[idx] * num_in_slice, 0.2, 3.0)
            dev.last_allocated_bw_hz = allocated_bw
            dev.last_tx_power_w = tx_p_w

            # Interference from concurrent active devices in other clusters
            interf_w = 0.0
            for other_idx in active_indices:
                if other_idx != idx:
                    other_dev = self.devices[other_idx]
                    if other_dev.associated_router_id == dev.associated_router_id:
                        # Intra-cell orthogonal PRBs have minimal leakage
                        interf_w += active_tx_powers_w[other_idx] * active_gains[other_idx] * 0.02
                    else:
                        # Inter-cell co-channel interference
                        other_router_pos = self.router_positions[dev.associated_router_id]
                        leakage_gain, _, _ = self.channel.compute_channel_gain(other_dev.position, other_router_pos)
                        interf_w += active_tx_powers_w[other_idx] * leakage_gain * 0.25

            # Compute SINR and Achievable Rate
            sinr = self.channel.compute_sinr(tx_p_w, gain, allocated_bw, interf_w)
            dev.last_sinr_db = float(10.0 * np.log10(max(sinr, 1e-5)))
            
            achievable_rate_bps = self.channel.compute_achievable_rate(allocated_bw, sinr)
            device_rates[idx] = achievable_rate_bps

            # Packet transmission
            if dev.queue:
                pkt = dev.queue[0]
                tx_capacity_bits = achievable_rate_bps * self.time_step_sec
                tx_capacity_bytes = int(tx_capacity_bits / 8)

                # URLLC / Tactile BLER checking
                is_delivered = True
                if dev.device_type == DeviceType.TACTILE_URLLC:
                    tactile_attempts += 1
                    symbols = int(allocated_bw * self.time_step_sec)
                    rate_per_sym = (pkt.size_bytes * 8) / max(1, symbols)
                    bler = self.channel.compute_finite_blocklength_error(symbols, rate_per_sym, sinr)
                    if np.random.rand() < bler:
                        is_delivered = False # Finite blocklength decoding error

                if is_delivered:
                    bytes_to_send = min(pkt.remaining_bytes, tx_capacity_bytes)
                    pkt.transmitted_bytes += bytes_to_send
                    slot_throughput_bits += bytes_to_send * 8

                    if pkt.is_fully_transmitted:
                        latency_ms = (self.current_time_ms - pkt.arrival_time_ms)
                        dev.total_packets_delivered += 1
                        dev.total_bits_delivered += pkt.size_bytes * 8
                        dev.queue.pop(0)

                        if dev.device_type == DeviceType.TACTILE_URLLC:
                            tactile_latencies.append(latency_ms)
                            tactile_deliveries += 1

                        if latency_ms <= pkt.latency_deadline_ms:
                            qos_satisfied_count += 1
                else:
                    dev.total_packets_dropped += 1

            # Energy consumption: RF transmission + Edge/Local computation
            comp_cycles = (pkt.computation_cycles if dev.queue else 0.0) * (1.0 - offload_ratio[idx])
            energy = dev.consume_energy(tx_p_w, self.time_step_sec, comp_cycles)
            slot_energy_joules += energy

        # 5. Closed-Loop Feedback Reconfiguration for Tactile Slices
        mean_tactile_lat = np.mean(tactile_latencies) if tactile_latencies else 1.5
        tactile_pdr = (tactile_deliveries / tactile_attempts) if tactile_attempts > 0 else 1.0
        reconfigured = self.slice_mgr.execute_closed_loop_reconfiguration(mean_tactile_lat, tactile_pdr)

        # 6. Compute Multi-Objective Reward
        reward = self._calculate_reward(
            slot_throughput_bits=slot_throughput_bits,
            slot_energy_joules=slot_energy_joules,
            tactile_latency_ms=mean_tactile_lat,
            tactile_pdr=tactile_pdr,
            active_rates=device_rates[active_indices],
            qos_satisfied_ratio=(qos_satisfied_count / max(1, len(active_indices))),
            dropped_packets=total_expired_packets
        )

        # 7. Update Spatio-Temporal History
        new_obs = self._get_normalized_states()
        self.state_history = np.roll(self.state_history, shift=-1, axis=1)
        self.state_history[:, -1, :] = new_obs

        done = (self.current_step >= self.max_steps)

        # 8. Detailed Metrics Compilation
        info = self._gather_step_metrics(
            slot_throughput_bits=slot_throughput_bits,
            slot_energy_joules=slot_energy_joules,
            tactile_latency_ms=mean_tactile_lat,
            device_rates=device_rates,
            active_count=len(active_indices),
            reconfigured=reconfigured
        )

        return new_obs, reward, done, info

    def _evaluate_handover(self, dev: IoTDevice):
        """Checks RSSI to candidate 6G mesh cluster heads and executes handover."""
        current_router_pos = self.router_positions[dev.associated_router_id]
        current_dist = self.channel.compute_distance_3d(dev.position, current_router_pos)

        best_router_id = dev.associated_router_id
        min_dist = current_dist

        for r_id, r_pos in enumerate(self.router_positions):
            dist = self.channel.compute_distance_3d(dev.position, r_pos)
            # Handover hysteresis margin: must be at least 15m closer
            if dist < (min_dist - 15.0):
                min_dist = dist
                best_router_id = r_id

        if best_router_id != dev.associated_router_id:
            self.total_handovers_attempted += 1
            dev.handover_attempts += 1
            
            # Handover success probability (higher when not moving too fast)
            handover_success_prob = max(0.85, 1.0 - (np.linalg.norm(dev.velocity) / 25.0))
            if np.random.rand() < handover_success_prob:
                dev.associated_router_id = best_router_id
                dev.handover_count += 1
                self.total_handovers_successful += 1

    def _calculate_reward(self, slot_throughput_bits: float, slot_energy_joules: float,
                          tactile_latency_ms: float, tactile_pdr: float,
                          active_rates: np.ndarray, qos_satisfied_ratio: float,
                          dropped_packets: int) -> float:
        """
        Calculates context-aware multi-objective scalar reward:
        R = w_th * R_th - w_lat * R_lat - w_en * R_en + w_spec * R_se + w_pdr * R_pdr + w_fair * J - w_pen * Drop
        """
        # 1. Throughput (Mbps)
        th_mbps = (slot_throughput_bits / 1e6) / self.time_step_sec
        r_th = np.tanh(th_mbps / 20.0)

        # 2. Latency penalty
        r_lat = np.tanh(tactile_latency_ms / 5.0)

        # 3. Energy penalty (Joules per slot)
        r_en = np.tanh(slot_energy_joules / 0.5)

        # 4. Spectral Efficiency (bps/Hz)
        se = (slot_throughput_bits / self.time_step_sec) / self.total_bw_hz
        r_se = np.tanh(se / 4.0)

        # 5. PDR
        r_pdr = tactile_pdr

        # 6. Jain's Fairness Index
        if len(active_rates) > 0 and np.sum(active_rates**2) > 0:
            jain = float((np.sum(active_rates) ** 2) / (len(active_rates) * np.sum(active_rates ** 2)))
        else:
            jain = 1.0

        # 7. Drop / SLA violation penalty
        drop_pen = min(2.0, dropped_packets * 0.1)

        reward = (
            self.rw['w_throughput'] * r_th
            - self.rw['w_latency_penalty'] * r_lat
            - self.rw['w_energy_penalty'] * r_en
            + self.rw['w_spectral_efficiency'] * r_se
            + self.rw['w_pdr'] * r_pdr
            + self.rw['w_fairness'] * jain
            - self.rw['w_qos_violation_penalty'] * drop_pen
        )
        return float(reward)

    def _gather_step_metrics(self, slot_throughput_bits: float, slot_energy_joules: float,
                             tactile_latency_ms: float, device_rates: np.ndarray,
                             active_count: int, reconfigured: bool) -> Dict[str, Any]:
        """Calculates instantaneous metrics required for research evaluation."""
        total_gen = sum(dev.total_packets_generated for dev in self.devices)
        total_del = sum(dev.total_packets_delivered for dev in self.devices)
        total_drop = sum(dev.total_packets_dropped for dev in self.devices)

        pdr = (total_del / max(1, total_gen)) * 100.0
        packet_loss_rate = (total_drop / max(1, total_gen)) * 100.0

        # Throughput
        th_mbps = (slot_throughput_bits / 1e6) / self.time_step_sec

        # Spectral Efficiency
        spec_eff = (slot_throughput_bits / self.time_step_sec) / self.total_bw_hz

        # Energy Efficiency (Mbits / Joule)
        energy_eff = (slot_throughput_bits / 1e6) / max(1e-6, slot_energy_joules)

        # Jain's Fairness Index across all devices with traffic
        active_rates = device_rates[device_rates > 0]
        if len(active_rates) > 0:
            jains_fairness = float((np.sum(active_rates) ** 2) / (len(active_rates) * np.sum(active_rates ** 2)))
        else:
            jains_fairness = 1.0

        # Handover Success Rate
        ho_success_rate = (
            (self.total_handovers_successful / max(1, self.total_handovers_attempted)) * 100.0
            if self.total_handovers_attempted > 0 else 100.0
        )

        # Resource & Bandwidth Utilization
        bw_utilization = min(100.0, (active_count / self.num_devices) * 100.0 * 1.2)
        resource_utilization = min(100.0, (active_count / self.num_prbs) * 100.0)

        # QoS Satisfaction Rate
        qos_satisfied = sum(
            1 for dev in self.devices 
            if dev.total_packets_delivered > 0 and (dev.total_packets_dropped / max(1, dev.total_packets_generated)) < 0.05
        )
        qos_rate = (qos_satisfied / self.num_devices) * 100.0

        # Blocking Probability (unserved devices due to PRB capacity limit)
        unserved = max(0, sum(1 for dev in self.devices if len(dev.queue) > 0) - active_count)
        blocking_prob = (unserved / max(1, self.num_devices)) * 100.0

        return {
            'spectral_efficiency': float(spec_eff),
            'network_throughput': float(th_mbps),
            'end_to_end_latency': float(tactile_latency_ms),
            'packet_delivery_ratio': float(pdr),
            'energy_efficiency': float(energy_eff),
            'resource_utilization': float(resource_utilization),
            'bandwidth_utilization': float(bw_utilization),
            'qos_satisfaction_rate': float(qos_rate),
            'packet_loss_rate': float(packet_loss_rate),
            'jains_fairness_index': float(jains_fairness),
            'blocking_probability': float(blocking_prob),
            'handover_success_rate': float(ho_success_rate),
            'active_devices_count': int(active_count),
            'slice_reconfigured': bool(reconfigured)
        }
