"""
6G-IoTMesh Environment Module
Simulates 6G Massive IoT mesh networks with mmWave/sub-THz channel modeling,
heterogeneous traffic slicing, and edge computing.
"""

from .channel_model import Channel6G
from .iot_device import IoTDevice, DeviceType, Packet
from .slice_manager import SliceManager, NetworkSlice
from .iot_mesh_env import IoTMeshEnv

__all__ = [
    'Channel6G',
    'IoTDevice',
    'DeviceType',
    'Packet',
    'SliceManager',
    'NetworkSlice',
    'IoTMeshEnv'
]
