"""
6G Sub-THz and mmWave Wireless Channel Model.
Implements 3GPP TR 38.901 path loss, molecular absorption, shadow fading,
fast fading (Rayleigh/Rician), multi-user spatial mesh interference,
and finite blocklength information theory for URLLC/Tactile IoT.
"""

import numpy as np
from scipy.special import erfc


class Channel6G:
    """
    Simulates physical layer propagation for 6G mesh IoT communications.
    Supports sub-THz and mmWave spectrum (e.g., 28 GHz to 140 GHz).
    """

    def __init__(self, carrier_frequency_ghz: float = 28.0,
                 total_bandwidth_mhz: float = 100.0,
                 noise_figure_db: float = 7.0,
                 noise_psd_dbm: float = -174.0):
        self.fc = carrier_frequency_ghz  # GHz
        self.total_bw_hz = total_bandwidth_mhz * 1e6  # Hz
        self.noise_figure_linear = 10.0 ** (noise_figure_db / 10.0)
        self.noise_psd_w_per_hz = (10.0 ** ((noise_psd_dbm - 30.0) / 10.0)) * self.noise_figure_linear
        
        # Molecular absorption attenuation at sub-THz / mmWave (dB/km)
        # 28 GHz: ~0.06 dB/km; 140 GHz: ~0.4 dB/km
        if self.fc >= 100.0:
            self.molecular_absorption_db_per_km = 0.40
        else:
            self.molecular_absorption_db_per_km = 0.06

    def compute_distance_3d(self, pos1: np.ndarray, pos2: np.ndarray) -> float:
        """Calculates Euclidean distance between two 3D coordinates (meters)."""
        dist = np.linalg.norm(np.array(pos1) - np.array(pos2))
        return max(float(dist), 1.0)  # Minimum distance 1 meter to avoid singularity

    def los_probability(self, distance_2d: float) -> float:
        """
        3GPP TR 38.901 Line-of-Sight (LOS) probability for Urban Micro (UMi).
        """
        if distance_2d <= 18.0:
            return 1.0
        return (18.0 / distance_2d) + np.exp(-distance_2d / 36.0) * (1.0 - (18.0 / distance_2d))

    def compute_path_loss(self, distance_3d: float, is_los: bool) -> float:
        """
        Computes 3GPP 38.901 path loss (dB) including atmospheric molecular absorption.
        """
        d = max(distance_3d, 1.0)
        fc = self.fc  # in GHz
        
        if is_los:
            # Free-space / LOS pathloss
            pl_db = 32.4 + 21.0 * np.log10(d) + 20.0 * np.log10(fc)
        else:
            # Non-Line-of-Sight (NLOS) pathloss
            pl_db = 35.3 + 31.9 * np.log10(d) + 20.0 * np.log10(fc)

        # Add molecular absorption
        pl_db += (self.molecular_absorption_db_per_km / 1000.0) * d
        return float(pl_db)

    def generate_shadowing(self, is_los: bool) -> float:
        """Generates log-normal shadow fading in dB."""
        std_dev = 4.0 if is_los else 7.82  # Standard deviation according to 3GPP
        return float(np.random.normal(0.0, std_dev))

    def generate_fast_fading(self, is_los: bool) -> float:
        """
        Generates small-scale fast fading channel power gain.
        Rician fading for LOS (K-factor = 9 dB), Rayleigh fading for NLOS.
        """
        if is_los:
            # Rician fading
            k_factor_linear = 10.0 ** (9.0 / 10.0)  # 9 dB K-factor
            mean_los = np.sqrt(k_factor_linear / (k_factor_linear + 1.0))
            sigma = np.sqrt(1.0 / (2.0 * (k_factor_linear + 1.0)))
            real = np.random.normal(mean_los, sigma)
            imag = np.random.normal(0.0, sigma)
            gain = real**2 + imag**2
        else:
            # Rayleigh fading (exponential power distribution with mean 1)
            gain = np.random.exponential(scale=1.0)
        return float(gain)

    def compute_channel_gain(self, tx_pos: np.ndarray, rx_pos: np.ndarray) -> tuple:
        """
        Computes composite channel gain (linear scale), path loss (dB), and LOS indicator.
        """
        dist_3d = self.compute_distance_3d(tx_pos, rx_pos)
        dist_2d = np.linalg.norm(np.array(tx_pos[:2]) - np.array(rx_pos[:2]))
        
        prob_los = self.los_probability(dist_2d)
        is_los = (np.random.rand() < prob_los)
        
        pl_db = self.compute_path_loss(dist_3d, is_los)
        sf_db = self.generate_shadowing(is_los)
        total_attenuation_db = pl_db + sf_db
        
        # Linear large-scale gain
        large_scale_gain = 10.0 ** (-total_attenuation_db / 10.0)
        
        # Small-scale fast fading
        fast_fading_gain = self.generate_fast_fading(is_los)
        
        composite_gain = large_scale_gain * fast_fading_gain
        return composite_gain, total_attenuation_db, is_los

    def compute_sinr(self, tx_power_w: float, channel_gain: float,
                     allocated_bw_hz: float, interference_power_w: float) -> float:
        """
        Calculates Signal-to-Interference-plus-Noise Ratio (SINR).
        """
        noise_power_w = self.noise_psd_w_per_hz * max(allocated_bw_hz, 1.0)
        rx_signal_w = tx_power_w * channel_gain
        sinr = rx_signal_w / (noise_power_w + interference_power_w + 1e-15)
        return float(sinr)

    def compute_achievable_rate(self, allocated_bw_hz: float, sinr_linear: float) -> float:
        """
        Shannon-Hartley capacity in bits per second (bps).
        """
        if allocated_bw_hz <= 0.0 or sinr_linear <= 0.0:
            return 0.0
        return float(allocated_bw_hz * np.log2(1.0 + sinr_linear))

    def compute_finite_blocklength_error(self, blocklength_symbols: int,
                                         rate_bits_per_symbol: float,
                                         sinr_linear: float) -> float:
        """
        Finite blocklength (Polyanskiy-Poor-Verdú) bound for URLLC / Tactile IoT.
        Approximates packet error probability under short packets.
        """
        if blocklength_symbols <= 0 or sinr_linear <= 0.0:
            return 1.0
        
        c_shannon = np.log2(1.0 + sinr_linear)
        # Channel dispersion V = 1 - (1 + sinr)^(-2) in (nats/symbol)^2, converted to bits
        v = (1.0 - (1.0 + sinr_linear) ** (-2.0)) * (np.log2(np.e) ** 2)
        v = max(v, 1e-6)
        
        # Argument of Q-function
        z = (c_shannon - rate_bits_per_symbol) * np.sqrt(blocklength_symbols) / np.sqrt(v)
        
        # Q(z) = 0.5 * erfc(z / sqrt(2))
        q_val = 0.5 * erfc(z / np.sqrt(2.0))
        return float(np.clip(q_val, 1e-7, 1.0))
