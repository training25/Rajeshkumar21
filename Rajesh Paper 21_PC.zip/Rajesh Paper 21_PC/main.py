"""
Main Execution Script for 6G-IoTMesh.
Runs end-to-end training, comparative benchmarking across all baselines,
computes all 15 performance metrics, runs SHAP interpretability, and exports publication figures.

Usage:
    python main.py
"""

import os
import yaml
import numpy as np
import pandas as pd

from env.iot_mesh_env import IoTMeshEnv
from models.ffr_pmn_agent import FFRPMAgent
from evaluation.benchmark_runner import BenchmarkRunner
from xai.shap_explainer import ResourceAllocationExplainer
from visualization.plot_results import Visualizer


def run_pipeline():
    print("=" * 80)
    print("6G-IoTMesh: An In-Content-Aware Elastic Resource Allocation for Massive IoT Networks")
    print("            using Deep Reinforcement Learning (FFR-PMN)")
    print("=" * 80)

    # 1. Load Configuration
    config_path = os.path.join(os.path.dirname(__file__), "config", "simulation_config.yaml")
    with open(config_path, "r") as f:
        config = yaml.safe_load(f)

    print(f"[*] Configuration Loaded:")
    print(f"    - Network Area: {config['network']['area_width']}m x {config['network']['area_height']}m x {config['network']['area_depth']}m")
    print(f"    - Carrier Frequency: {config['network']['carrier_frequency_ghz']} GHz (Sub-THz/mmWave)")
    print(f"    - Bandwidth: {config['network']['total_bandwidth_mhz']} MHz | PRBs: {config['network']['num_prbs']}")
    print(f"    - Massive IoT Devices: {config['network']['num_devices']} nodes | Mesh Routers: {config['network']['num_mesh_routers']}")
    print("-" * 80)

    # 2. Run Comparative Multi-Episode Benchmark
    runner = BenchmarkRunner(config, num_episodes=12, steps_per_episode=50)
    results = runner.run_full_benchmark()

    # 3. Compile and Display Comparison Table for All 15 Metrics
    print("\n" + "=" * 80)
    print("                  BENCHMARK EVALUATION SUMMARY (ALL 15 METRICS)")
    print("=" * 80)
    comparison_df = BenchmarkRunner.generate_comparison_table(results)
    
    # Format display
    pd.set_option('display.max_columns', None)
    pd.set_option('display.width', 1000)
    pd.set_option('display.float_format', lambda x: f'{x:.3f}')
    print(comparison_df)

    # Save summary table to CSV
    os.makedirs("results", exist_ok=True)
    csv_path = os.path.join("results", "benchmark_metrics_summary.csv")
    comparison_df.to_csv(csv_path)
    print(f"\n[+] Saved numerical metrics table to: {csv_path}")

    # 4. Explainable AI (XAI) Analysis using SHAP
    print("\n" + "=" * 80)
    print("               SHAP EXPLAINABILITY & TRANSPARENCY ANALYSIS")
    print("=" * 80)
    env_eval = IoTMeshEnv(config_dict=config)
    env_eval.reset()
    
    # Extract background states
    bg_data = env_eval._get_normalized_states()
    test_instances = bg_data[:10] # Sample devices for local explanation

    ffr_agent = results["FFR-PMN (Proposed)"].algo_name
    # Use trained global model from FFR-PMN
    trained_agent = runner.trained_ffr_agent if runner.trained_ffr_agent is not None else FFRPMAgent(config)
    explainer = ResourceAllocationExplainer(
        agent_model=trained_agent.global_model,
        feature_names=config['xai']['feature_names'],
        temporal_window=config['federated_rl']['temporal_window_size']
    )

    shap_results = explainer.explain_dataset(bg_data, test_instances, target_head='bw')
    importance_df = shap_results['feature_importance_df']

    print("[*] Global Top-8 Influential Features for Elastic Resource Allocation:")
    print(importance_df.head(8).to_string(index=False))

    # Save SHAP feature importance to CSV
    shap_csv_path = os.path.join("results", "shap_feature_importance.csv")
    importance_df.to_csv(shap_csv_path, index=False)

    # Local sample report for Device 0 (e.g. Tactile IoT device)
    dev0 = env_eval.devices[0]
    local_report = explainer.generate_local_explanation_report(
        instance=test_instances[0],
        shap_row=shap_results['shap_values'][0],
        device_id=dev0.device_id,
        slice_name=env_eval.slice_mgr.slices[dev0.device_type].name,
        target_head='Bandwidth Allocation'
    )
    print("\n" + local_report)

    # 5. Generate Publication-Quality Plots
    print("\n" + "=" * 80)
    print(" GENERATING RESEARCH VISUALIZATIONS")
    print("=" * 80)
    viz = Visualizer(output_dir="output_figures")
    viz.plot_metric_bars(comparison_df, filename="all_15_metrics_comparison.png")
    viz.plot_convergence(results, filename="convergence_reward.png")
    viz.plot_latency_cdf(results, filename="latency_cdf.png")
    viz.plot_shap_summary(importance_df, filename="shap_feature_importance.png")

    print("\n" + "=" * 80)
    print("[SUCCESS] 6G-IoTMesh Simulation, Evaluation, XAI, and Visualization Completed!")
    print("=" * 80)


if __name__ == "__main__":
    run_pipeline()
