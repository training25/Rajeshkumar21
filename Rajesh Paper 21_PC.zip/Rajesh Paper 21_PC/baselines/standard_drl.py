"""
Centralized Standard Deep Reinforcement Learning Baseline (Centralized PPO).
Implements a standard MLP Actor-Critic policy without in-content awareness,
without Florist Optimization, and without federated mesh architecture.
"""

import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.distributions import Normal, Bernoulli
import numpy as np
from typing import Dict, List, Tuple


class CentralizedActorCritic(nn.Module):
    """
    Standard Feedforward Multi-Layer Perceptron (MLP) for centralized resource allocation.
    """
    def __init__(self, state_dim: int = 18, num_devices: int = 120):
        super(CentralizedActorCritic, self).__init__()
        self.state_dim = state_dim
        self.num_devices = num_devices

        # Standard Feedforward Feature Extractor (no GAT, no GRU)
        self.shared_mlp = nn.Sequential(
            nn.Linear(state_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 64),
            nn.ReLU()
        )

        # Actor heads
        self.actor_inclusion = nn.Sequential(
            nn.Linear(64, 1),
            nn.Sigmoid()
        )
        self.actor_resource = nn.Sequential(
            nn.Linear(64, 3), # [power, bw_share, offload]
            nn.Sigmoid()
        )
        self.actor_log_std = nn.Parameter(torch.ones(3) * -0.5)

        # Critic head
        self.critic = nn.Linear(64, 1)

    def forward(self, state: torch.Tensor):
        # state: (num_devices, state_dim)
        feat = self.shared_mlp(state)
        inclusion_prob = self.actor_inclusion(feat).squeeze(-1)
        res_mean = self.actor_resource(feat)
        value = self.critic(feat).squeeze(-1)
        return inclusion_prob, res_mean, value


class StandardCentralizedDRL:
    """
    Centralized standard PPO agent without in-content awareness or FOA.
    """
    def __init__(self, config: dict):
        self.config = config
        self.num_devices = config['network']['num_devices']
        self.state_dim = config['federated_rl']['state_dim']
        
        self.model = CentralizedActorCritic(self.state_dim, self.num_devices)
        self.optimizer = optim.Adam(self.model.parameters(), lr=config['federated_rl']['actor_lr'])
        
        self.gamma = config['federated_rl']['gamma']
        self.clip_eps = config['federated_rl']['clip_epsilon']

        self.states = []
        self.inclusion_acts = []
        self.resource_acts = []
        self.log_probs = []
        self.rewards = []
        self.values = []
        self.dones = []

    @property
    def actor_log_std(self):
        return self.model.actor_log_std

    def select_actions(self, current_states: np.ndarray, deterministic: bool = False) -> Dict[str, np.ndarray]:
        """
        current_states: (num_devices, state_dim)
        """
        self.model.eval()
        with torch.no_grad():
            t_state = torch.from_numpy(current_states).float()
            inc_probs, res_means, vals = self.model(t_state)

            if deterministic:
                inc_act = (inc_probs >= 0.5).float()
                res_act = res_means
                log_p = torch.zeros_like(inc_probs)
            else:
                bern = Bernoulli(probs=torch.clamp(inc_probs, 1e-6, 1.0 - 1e-6))
                inc_act = bern.sample()

                std = torch.exp(self.model.actor_log_std)
                norm = Normal(res_means, std)
                res_act = torch.clamp(norm.sample(), 0.0, 1.0)

                log_p = bern.log_prob(inc_act) + norm.log_prob(res_act).sum(dim=-1)

        return {
            'ue_inclusion': inc_act.cpu().numpy(),
            'power_allocation': res_act[:, 0].cpu().numpy(),
            'bw_share': res_act[:, 1].cpu().numpy(),
            'offload_ratio': res_act[:, 2].cpu().numpy(),
            'log_probs': log_p.cpu().numpy(),
            'values': vals.cpu().numpy()
        }

    def store_transition(self, state, inc_act, res_act, log_p, reward, val, done):
        self.states.append(state)
        self.inclusion_acts.append(inc_act)
        self.resource_acts.append(res_act)
        self.log_probs.append(log_p)
        self.rewards.append(reward)
        self.values.append(val)
        self.dones.append(done)

    def train_step(self) -> float:
        """Executes centralized PPO update."""
        if len(self.rewards) == 0:
            return 0.0

        rewards = np.array(self.rewards)
        discounted_returns = []
        running_ret = 0.0
        for r in reversed(rewards):
            running_ret = r + self.gamma * running_ret
            discounted_returns.insert(0, running_ret)

        ret_tensor = torch.tensor(discounted_returns, dtype=torch.float32)
        val_tensor = torch.tensor(self.values, dtype=torch.float32)
        adv_tensor = ret_tensor - val_tensor
        if len(adv_tensor) > 1 and adv_tensor.std() > 1e-8:
            adv_tensor = (adv_tensor - adv_tensor.mean()) / (adv_tensor.std() + 1e-8)

        self.model.train()
        total_loss = 0.0

        for _ in range(self.config['federated_rl']['local_epochs']):
            for step_idx in range(len(self.states)):
                s = torch.tensor(self.states[step_idx], dtype=torch.float32)
                inc_a = torch.tensor(self.inclusion_acts[step_idx], dtype=torch.float32)
                res_a = torch.tensor(self.resource_acts[step_idx], dtype=torch.float32)
                old_lp = torch.tensor(self.log_probs[step_idx], dtype=torch.float32)

                inc_probs, res_means, val = self.model(s)
                bern = Bernoulli(probs=torch.clamp(inc_probs, 1e-6, 1.0 - 1e-6))
                std = torch.exp(self.model.actor_log_std)
                norm = Normal(res_means, std)

                curr_lp = bern.log_prob(inc_a) + norm.log_prob(res_a).sum(dim=-1)
                
                ratio = torch.exp(curr_lp - old_lp)
                surr1 = ratio * adv_tensor[step_idx]
                surr2 = torch.clamp(ratio, 1.0 - self.clip_eps, 1.0 + self.clip_eps) * adv_tensor[step_idx]
                p_loss = -torch.min(surr1, surr2).mean()
                v_loss = F.mse_loss(val.mean(), ret_tensor[step_idx])

                loss = p_loss + 0.5 * v_loss

                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()
                total_loss += loss.item()

        self.states.clear()
        self.inclusion_acts.clear()
        self.resource_acts.clear()
        self.log_probs.clear()
        self.rewards.clear()
        self.values.clear()
        self.dones.clear()

        return total_loss / max(1, len(discounted_returns))
