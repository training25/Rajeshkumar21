"""
Baseline Resource Allocation Algorithms for Comparative Evaluation.
Includes Static/Rule-Based Slicing and Centralized Standard DRL (PPO).
"""

from .static_rule_based import StaticRuleBasedScheduler
from .standard_drl import StandardCentralizedDRL

__all__ = [
    'StaticRuleBasedScheduler',
    'StandardCentralizedDRL'
]
