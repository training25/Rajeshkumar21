"""
Static and Rule-Based Resource Allocation Baseline.
Implements static network slicing, Round-Robin UE inclusion,
and fixed-power Proportional Fair spectrum division without dynamic feedback.
"""

import numpy as np
from typing import Dict, List, Any


class StaticRuleBasedScheduler:
    """
    Conventional 5G/6G baseline:
    - Fixed static slice partition (no elastic borrowing).
    - Round-Robin / Queue-based UE inclusion.
    - Uniform power and equal PRB division within each slice.
    """
    def __init__(self, config: dict):
        self.config = config
        self.num_devices = config['network']['num_devices']
        self.round_robin_pointer = 0

    def select_actions(self, env_devices: list) -> Dict[str, np.ndarray]:
        """
        Generates static rule-based decisions for all IoT devices.
        """
        ue_inclusion = np.zeros(self.num_devices)
        power_alloc = np.zeros(self.num_devices)
        bw_share = np.zeros(self.num_devices)
        offload_ratio = np.zeros(self.num_devices)

        # 1. Round-Robin UE Inclusion with backlog check
        # Allow up to 30 active devices per slot to respect PRB limits
        max_active = min(32, self.num_devices)
        scheduled_count = 0
        
        for offset in range(self.num_devices):
            idx = (self.round_robin_pointer + offset) % self.num_devices
            dev = env_devices[idx]
            if len(dev.queue) > 0 and dev.residual_battery_ratio > 0.05:
                ue_inclusion[idx] = 1.0
                # Static transmit power (e.g. 70% of max power)
                power_alloc[idx] = 0.70
                # Equal bandwidth weighting
                bw_share[idx] = 1.0
                # Static rule: No dynamic offloading (all local processing)
                offload_ratio[idx] = 0.0

                scheduled_count += 1
                if scheduled_count >= max_active:
                    self.round_robin_pointer = (idx + 1) % self.num_devices
                    break

        if scheduled_count == 0:
            self.round_robin_pointer = (self.round_robin_pointer + max_active) % self.num_devices

        # Normalize bw_share among scheduled devices
        if scheduled_count > 0:
            bw_share = bw_share / scheduled_count

        return {
            'ue_inclusion': ue_inclusion,
            'power_allocation': power_alloc,
            'bw_share': bw_share,
            'offload_ratio': offload_ratio
        }
