"""
Performance Metrics Tracker for 6G-IoTMesh.
Implements calculations and statistics for all 15 proposed metrics:
1. Spectral efficiency (bps/Hz)
2. Network throughput (Mbps)
3. End-to-end latency (ms)
4. Packet delivery ratio (PDR %)
5. Energy efficiency (Mbits/Joule)
6. Resource utilization (%)
7. Bandwidth utilization (%)
8. QoS satisfaction rate (%)
9. Packet loss rate (%)
10. Jain's fairness index (0 to 1)
11. Blocking probability (%)
12. Handover success rate (%)
13. Convergence time (episodes / sec)
14. Cumulative reward
15. Resource allocation overhead (signaling & computation overhead)
"""

import time
import numpy as np
import pandas as pd
from typing import Dict, List, Any


class MetricsTracker:
    """
    Collects, aggregates, and exports all 15 metrics for simulation benchmarking.
    """
    METRIC_NAMES = [
        "spectral_efficiency",
        "network_throughput",
        "end_to_end_latency",
        "packet_delivery_ratio",
        "energy_efficiency",
        "resource_utilization",
        "bandwidth_utilization",
        "qos_satisfaction_rate",
        "packet_loss_rate",
        "jains_fairness_index",
        "blocking_probability",
        "handover_success_rate",
        "convergence_time",
        "cumulative_reward",
        "resource_allocation_overhead"
    ]

    def __init__(self, algorithm_name: str):
        self.algo_name = algorithm_name
        self.step_history: List[Dict[str, float]] = []
        self.episode_rewards: List[float] = []
        self.episode_overhead_ms: List[float] = []
        self.convergence_time_episodes = 0
        self.start_wall_time = time.time()
        self.total_wall_time_sec = 0.0

    def record_step(self, step_metrics: Dict[str, Any], reward: float, overhead_ms: float = 1.2):
        """Records metrics from an individual simulation step."""
        entry = {k: step_metrics.get(k, 0.0) for k in self.METRIC_NAMES if k in step_metrics}
        entry['reward'] = reward
        entry['overhead_ms'] = overhead_ms
        self.step_history.append(entry)

    def finish_episode(self, episode_reward: float, overhead_ms: float):
        """Closes an episode and tracks convergence."""
        self.episode_rewards.append(episode_reward)
        self.episode_overhead_ms.append(overhead_ms)

        # Detect convergence: moving average variance < threshold
        if len(self.episode_rewards) >= 10 and self.convergence_time_episodes == 0:
            recent = self.episode_rewards[-5:]
            if np.std(recent) < 0.25 * (np.abs(np.mean(recent)) + 1e-4):
                self.convergence_time_episodes = len(self.episode_rewards)

    def finalize(self):
        """Finalizes wall-clock timer."""
        self.total_wall_time_sec = time.time() - self.start_wall_time
        if self.convergence_time_episodes == 0:
            self.convergence_time_episodes = len(self.episode_rewards)

    def get_summary(self) -> Dict[str, float]:
        """
        Computes final summary statistics (mean values) across all 15 metrics.
        """
        if not self.step_history:
            return {m: 0.0 for m in self.METRIC_NAMES}

        df = pd.DataFrame(self.step_history)
        summary = {}

        # 1. Spectral efficiency (bps/Hz)
        summary["spectral_efficiency"] = float(df["spectral_efficiency"].mean())

        # 2. Network throughput (Mbps)
        summary["network_throughput"] = float(df["network_throughput"].mean())

        # 3. End-to-end latency (ms)
        summary["end_to_end_latency"] = float(df["end_to_end_latency"].mean())

        # 4. Packet delivery ratio (%)
        summary["packet_delivery_ratio"] = float(df["packet_delivery_ratio"].iloc[-1])

        # 5. Energy efficiency (Mbits/Joule)
        summary["energy_efficiency"] = float(df["energy_efficiency"].mean())

        # 6. Resource utilization (%)
        summary["resource_utilization"] = float(df["resource_utilization"].mean())

        # 7. Bandwidth utilization (%)
        summary["bandwidth_utilization"] = float(df["bandwidth_utilization"].mean())

        # 8. QoS satisfaction rate (%)
        summary["qos_satisfaction_rate"] = float(df["qos_satisfaction_rate"].mean())

        # 9. Packet loss rate (%)
        summary["packet_loss_rate"] = float(df["packet_loss_rate"].iloc[-1])

        # 10. Jain's fairness index
        summary["jains_fairness_index"] = float(df["jains_fairness_index"].mean())

        # 11. Blocking probability (%)
        summary["blocking_probability"] = float(df["blocking_probability"].mean())

        # 12. Handover success rate (%)
        summary["handover_success_rate"] = float(df["handover_success_rate"].iloc[-1])

        # 13. Convergence time (episodes)
        summary["convergence_time"] = float(self.convergence_time_episodes)

        # 14. Cumulative reward
        summary["cumulative_reward"] = float(np.sum(self.episode_rewards))

        # 15. Resource allocation overhead (ms execution time per slot)
        summary["resource_allocation_overhead"] = float(np.mean(self.episode_overhead_ms) if self.episode_overhead_ms else df["overhead_ms"].mean())

        return summary

    def get_dataframe(self) -> pd.DataFrame:
        """Returns step-by-step DataFrame for time-series analysis."""
        return pd.DataFrame(self.step_history)
