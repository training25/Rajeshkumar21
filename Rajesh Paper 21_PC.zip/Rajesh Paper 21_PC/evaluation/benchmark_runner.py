"""
Comparative Benchmark Runner for 6G-IoTMesh.
Runs automated Monte-Carlo simulation experiments comparing:
1. Proposed FFR-PMN (6G-IoTMesh with FOA and Closed-Loop Feedback)
2. Standard Centralized DRL (PPO without FOA or In-Content awareness)
3. Static & Rule-Based Allocation (Proportional Fair / Round-Robin)
"""

import time
import copy
import numpy as np
import pandas as pd
from typing import Dict, List, Any

from env.iot_mesh_env import IoTMeshEnv
from models.ffr_pmn_agent import FFRPMAgent
from baselines.standard_drl import StandardCentralizedDRL
from baselines.static_rule_based import StaticRuleBasedScheduler
from .metrics import MetricsTracker


class BenchmarkRunner:
    """
    Coordinates multi-episode execution across all algorithms and compiles comparison metrics.
    """
    def __init__(self, config: dict, num_episodes: int = 15, steps_per_episode: int = 60):
        self.config = config
        self.num_episodes = num_episodes
        self.steps_per_episode = steps_per_episode
        self.trained_ffr_agent = None

    def run_ffr_pmn(self) -> MetricsTracker:
        """Evaluates the proposed 6G-IoTMesh FFR-PMN architecture."""
        print("[*] Running Proposed 6G-IoTMesh (FFR-PMN) Simulation...")
        env = IoTMeshEnv(config_dict=self.config)
        env.max_steps = self.steps_per_episode
        agent = FFRPMAgent(self.config)
        self.trained_ffr_agent = agent
        tracker = MetricsTracker("Proposed FFR-PMN")

        for ep in range(self.num_episodes):
            obs = env.reset()
            ep_reward = 0.0
            t_ep_start = time.time()

            for step in range(self.steps_per_episode):
                t0 = time.time()
                # Action selection through distributed mesh agents
                actions = agent.act_for_all_devices(env.devices, env.state_history)
                overhead_ms = (time.time() - t0) * 1000.0

                next_obs, reward, done, info = env.step(actions)
                ep_reward += reward

                # Store rollout for federated training
                agent.store_distributed_rollout(env.devices, env.state_history, actions, reward, done)
                tracker.record_step(info, reward, overhead_ms=overhead_ms)

                if done:
                    break

            # Local PPO training at each Mesh Router
            cluster_losses = []
            for c_agent in agent.cluster_agents:
                loss = c_agent.train_local_policy(last_value=0.0)
                cluster_losses.append(loss)

            # Federated Aggregation with Florist Optimization Algorithm (FOA)
            cluster_scores = [1.0 / (1.0 + l) for l in cluster_losses]
            agent.federated_aggregation_with_foa(cluster_scores)

            ep_overhead_ms = (time.time() - t_ep_start) * 1000.0 / self.steps_per_episode
            tracker.finish_episode(ep_reward, ep_overhead_ms)
            if (ep + 1) % 5 == 0 or ep == self.num_episodes - 1:
                print(f"    Episode {ep + 1}/{self.num_episodes} | Reward: {ep_reward:.2f} | Latency: {info['end_to_end_latency']:.2f} ms | PDR: {info['packet_delivery_ratio']:.1f}%")

        tracker.finalize()
        return tracker

    def run_standard_drl(self) -> MetricsTracker:
        """Evaluates Centralized Standard DRL (PPO)."""
        print("[*] Running Centralized Standard DRL Baseline...")
        env = IoTMeshEnv(config_dict=self.config)
        env.max_steps = self.steps_per_episode
        drl_agent = StandardCentralizedDRL(self.config)
        tracker = MetricsTracker("Standard DRL (PPO)")

        for ep in range(self.num_episodes):
            obs = env.reset()
            ep_reward = 0.0
            t_ep_start = time.time()

            for step in range(self.steps_per_episode):
                t0 = time.time()
                # Centralized state (current normalized states)
                actions = drl_agent.select_actions(obs)
                # Centralized scheduling incurs higher backhaul latency overhead
                overhead_ms = (time.time() - t0) * 1000.0 + 3.5

                next_obs, reward, done, info = env.step(actions)
                ep_reward += reward

                drl_agent.store_transition(
                    obs, actions['ue_inclusion'],
                    np.stack([actions['power_allocation'], actions['bw_share'], actions['offload_ratio']], axis=-1),
                    actions['log_probs'], reward, actions['values'].mean(), done
                )
                tracker.record_step(info, reward, overhead_ms=overhead_ms)
                obs = next_obs
                if done:
                    break

            drl_agent.train_step()
            ep_overhead_ms = (time.time() - t_ep_start) * 1000.0 / self.steps_per_episode
            tracker.finish_episode(ep_reward, ep_overhead_ms)
            if (ep + 1) % 5 == 0 or ep == self.num_episodes - 1:
                print(f"    Episode {ep + 1}/{self.num_episodes} | Reward: {ep_reward:.2f} | Latency: {info['end_to_end_latency']:.2f} ms | PDR: {info['packet_delivery_ratio']:.1f}%")

        tracker.finalize()
        return tracker

    def run_static_rule_based(self) -> MetricsTracker:
        """Evaluates Static / Rule-Based Allocation."""
        print("[*] Running Static & Rule-Based Allocation Baseline...")
        # Disable closed-loop feedback for purely static slicing baseline
        static_cfg = copy.deepcopy(self.config)
        static_cfg['closed_loop_feedback']['enabled'] = False

        env = IoTMeshEnv(config_dict=static_cfg)
        env.max_steps = self.steps_per_episode
        scheduler = StaticRuleBasedScheduler(static_cfg)
        tracker = MetricsTracker("Static Rule-Based")

        for ep in range(self.num_episodes):
            obs = env.reset()
            ep_reward = 0.0
            t_ep_start = time.time()

            for step in range(self.steps_per_episode):
                t0 = time.time()
                actions = scheduler.select_actions(env.devices)
                overhead_ms = (time.time() - t0) * 1000.0 + 0.2

                next_obs, reward, done, info = env.step(actions)
                ep_reward += reward

                tracker.record_step(info, reward, overhead_ms=overhead_ms)
                if done:
                    break

            ep_overhead_ms = (time.time() - t_ep_start) * 1000.0 / self.steps_per_episode
            tracker.finish_episode(ep_reward, ep_overhead_ms)

        tracker.finalize()
        print("    Static Rule-Based Completed.")
        return tracker

    def run_full_benchmark(self) -> Dict[str, MetricsTracker]:
        """Runs comparative benchmark for all schemes and returns results."""
        results = {
            "FFR-PMN (Proposed)": self.run_ffr_pmn(),
            "Standard DRL": self.run_standard_drl(),
            "Static Slicing": self.run_static_rule_based()
        }
        return results

    @staticmethod
    def generate_comparison_table(results: Dict[str, MetricsTracker]) -> pd.DataFrame:
        """Compiles a clean pandas comparison table across all 15 metrics."""
        data = {}
        for algo_name, tracker in results.items():
            data[algo_name] = tracker.get_summary()

        df = pd.DataFrame(data)
        df.index.name = "Metric"
        return df
