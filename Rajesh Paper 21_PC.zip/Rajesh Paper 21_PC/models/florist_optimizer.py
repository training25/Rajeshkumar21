"""
Florist Optimization Algorithm (FOA).
Nature-inspired meta-heuristic optimization algorithm modeling flower selection,
aesthetic bouquet arrangement, scent dispersion via Lévy flight,
and seasonal flower pruning for meta-learning and federated aggregation weighting.
"""

import numpy as np
from typing import Callable, Tuple, Optional


class FloristOptimizer:
    """
    Implements the Florist Optimization Algorithm (FOA).
    Used in FFR-PMN for:
    1. Global parameter search and meta-initialization of policy sub-networks.
    2. Dynamic federated weight aggregation across 6G mesh clusters.
    3. Combinatorial UE inclusion search under interference constraints.
    """
    def __init__(self, num_flowers: int = 20, max_iter: int = 25,
                 dim: int = 32, lb: float = -1.0, ub: float = 1.0,
                 scent_dispersion_rate: float = 0.25,
                 aesthetic_arrangement_prob: float = 0.65,
                 seasonal_pruning_ratio: float = 0.20):
        self.num_flowers = num_flowers  # Population size of bouquets
        self.max_iter = max_iter
        self.dim = dim
        self.lb = np.ones(dim) * lb if np.isscalar(lb) else np.array(lb)
        self.ub = np.ones(dim) * ub if np.isscalar(ub) else np.array(ub)
        
        self.scent_rate = scent_dispersion_rate
        self.p_arrange = aesthetic_arrangement_prob
        self.pruning_ratio = seasonal_pruning_ratio

        # State
        self.population = np.zeros((self.num_flowers, self.dim))
        self.fitness = np.full(self.num_flowers, -np.inf)
        self.best_bouquet = None
        self.best_fitness = -np.inf
        self.convergence_history = []

    def _initialize_population(self):
        """Phase 1: Flower Collection & Population Initialization."""
        self.population = self.lb + np.random.rand(self.num_flowers, self.dim) * (self.ub - self.lb)
        self.fitness = np.full(self.num_flowers, -np.inf)
        self.best_fitness = -np.inf
        self.convergence_history = []

    def _levy_flight(self, beta: float = 1.5) -> np.ndarray:
        """
        Generates step size based on Lévy distribution (Scent Dispersion).
        Mantegna's algorithm for heavy-tailed stochastic exploration.
        """
        import math
        sigma_num = math.gamma(1.0 + beta) * math.sin(math.pi * beta / 2.0)
        sigma_den = math.gamma((1.0 + beta) / 2.0) * beta * (2.0 ** ((beta - 1.0) / 2.0))
        sigma_u = (sigma_num / sigma_den) ** (1.0 / beta)
        
        u = np.random.normal(0.0, sigma_u, size=self.dim)
        v = np.random.normal(0.0, 1.0, size=self.dim)
        step = u / (np.abs(v) ** (1.0 / beta))
        return step

    def optimize(self, objective_func: Callable[[np.ndarray], float],
                 initial_seed: Optional[np.ndarray] = None) -> Tuple[np.ndarray, float]:
        """
        Executes FOA optimization cycle.
        Maximizes objective_func (fitness).
        """
        self._initialize_population()
        
        # Inject initial seed solution if provided (e.g. from previous FL round)
        if initial_seed is not None and len(initial_seed) == self.dim:
            self.population[0] = np.clip(initial_seed, self.lb, self.ub)

        # Initial fitness evaluation
        for i in range(self.num_flowers):
            self.fitness[i] = objective_func(self.population[i])
            if self.fitness[i] > self.best_fitness:
                self.best_fitness = self.fitness[i]
                self.best_bouquet = self.population[i].copy()

        self.convergence_history.append(self.best_fitness)

        # Iterative Search Cycle
        for it in range(self.max_iter):
            # Sort population by fitness (freshest flowers ranked at top)
            sorted_indices = np.argsort(-self.fitness)
            self.population = self.population[sorted_indices]
            self.fitness = self.fitness[sorted_indices]
            self.best_bouquet = self.population[0].copy()
            self.best_fitness = self.fitness[0]

            # Dynamic scent adaptation over time: higher at start, finer at end
            current_scent = self.scent_rate * (1.0 - (it / self.max_iter))

            for i in range(self.num_flowers):
                candidate = self.population[i].copy()
                
                # Phase 2: Aesthetic Bouquet Arrangement (Local Search)
                if np.random.rand() < self.p_arrange:
                    # Select two random distinct flowers
                    r1, r2 = np.random.choice(self.num_flowers, size=2, replace=False)
                    phi = np.random.uniform(-1.0, 1.0, size=self.dim)
                    candidate = (self.population[i] + 
                                 phi * (self.best_bouquet - self.population[i]) + 
                                 np.random.rand() * (self.population[r1] - self.population[r2]))
                
                # Phase 3: Scent Dispersion & Customer Attraction (Global Lévy Exploration)
                else:
                    levy_step = self._levy_flight(beta=1.5)
                    candidate = self.population[i] + current_scent * levy_step * (self.population[i] - self.best_bouquet)

                # Boundary clipping
                candidate = np.clip(candidate, self.lb, self.ub)

                # Evaluate fitness
                cand_fitness = objective_func(candidate)
                if cand_fitness > self.fitness[i]:
                    self.population[i] = candidate
                    self.fitness[i] = cand_fitness
                    if cand_fitness > self.best_fitness:
                        self.best_fitness = cand_fitness
                        self.best_bouquet = candidate.copy()

            # Phase 4: Seasonal Flower Pruning & Wildflower Refreshment
            num_prune = int(np.round(self.pruning_ratio * self.num_flowers))
            for p in range(self.num_flowers - num_prune, self.num_flowers):
                # Replace wilting bouquets with fresh random samples
                fresh_flower = self.lb + np.random.rand(self.dim) * (self.ub - self.lb)
                self.population[p] = fresh_flower
                self.fitness[p] = objective_func(fresh_flower)
                if self.fitness[p] > self.best_fitness:
                    self.best_fitness = self.fitness[p]
                    self.best_bouquet = fresh_flower.copy()

            self.convergence_history.append(self.best_fitness)

        return self.best_bouquet, self.best_fitness
