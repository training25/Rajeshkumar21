"""
Multi-Dimensional Spatio-Temporal State Encoder for 6G-IoTMesh.
Combines Graph Attention (spatial topology and interference),
Gated Recurrent Units (temporal queue dynamics and channel fading),
and In-Content metadata fusion (tactile priority, computation demand).
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np


class SpatialGraphAttention(nn.Module):
    """
    Spatial Attention layer modeling mutual interference and mesh proximity
    between massive IoT devices.
    """
    def __init__(self, in_features: int, out_features: int, num_heads: int = 4):
        super(SpatialGraphAttention, self).__init__()
        self.num_heads = num_heads
        self.out_features = out_features
        self.head_dim = out_features // num_heads

        self.w_q = nn.Linear(in_features, out_features, bias=False)
        self.w_k = nn.Linear(in_features, out_features, bias=False)
        self.w_v = nn.Linear(in_features, out_features, bias=False)
        self.out_proj = nn.Linear(out_features, out_features)

    def forward(self, x: torch.Tensor, adj_mask: torch.Tensor = None) -> torch.Tensor:
        """
        x: (batch_size, num_nodes, in_features)
        adj_mask: (batch_size, num_nodes, num_nodes) optional distance/connectivity mask
        """
        batch_size, num_nodes, _ = x.shape
        q = self.w_q(x).view(batch_size, num_nodes, self.num_heads, self.head_dim).transpose(1, 2)
        k = self.w_k(x).view(batch_size, num_nodes, self.num_heads, self.head_dim).transpose(1, 2)
        v = self.w_v(x).view(batch_size, num_nodes, self.num_heads, self.head_dim).transpose(1, 2)

        # Scaled Dot-Product Attention: (B, H, N, N)
        scores = torch.matmul(q, k.transpose(-2, -1)) / np.sqrt(self.head_dim)
        if adj_mask is not None:
            mask = adj_mask.unsqueeze(1) # Broadcast over heads
            scores = scores.masked_fill(mask == 0, -1e9)

        attn_weights = F.softmax(scores, dim=-1)
        out = torch.matmul(attn_weights, v) # (B, H, N, head_dim)
        out = out.transpose(1, 2).contiguous().view(batch_size, num_nodes, self.out_features)
        return self.out_proj(out)


class SpatioTemporalStateEncoder(nn.Module):
    """
    Unified multi-dimensional encoder mapping raw normalized IoT metrics
    into dense context embeddings for reinforcement learning policy networks.
    """
    def __init__(self, state_dim: int = 18, temporal_window: int = 5,
                 spatial_embed_dim: int = 32, temporal_hidden_dim: int = 32,
                 fused_latent_dim: int = 64):
        super(SpatioTemporalStateEncoder, self).__init__()
        self.state_dim = state_dim
        self.temporal_window = temporal_window
        self.fused_latent_dim = fused_latent_dim

        # 1. Temporal Processing: GRU over sequence of window T_w
        self.temporal_gru = nn.GRU(
            input_size=state_dim,
            hidden_size=temporal_hidden_dim,
            num_layers=1,
            batch_first=True
        )

        # 2. Spatial Processing: Spatial Attention over IoT node topology
        self.spatial_attn = SpatialGraphAttention(
            in_features=temporal_hidden_dim,
            out_features=spatial_embed_dim,
            num_heads=4
        )

        # 3. In-Content Awareness Feature Extractor
        # Focuses on tactile urgency, content size, deadline, computation demand
        self.content_mlp = nn.Sequential(
            nn.Linear(state_dim, 32),
            nn.ReLU(),
            nn.Linear(32, 32),
            nn.ReLU()
        )

        # 4. Multimodal Fusion Network
        fusion_input_dim = temporal_hidden_dim + spatial_embed_dim + 32
        self.fusion_network = nn.Sequential(
            nn.Linear(fusion_input_dim, fused_latent_dim),
            nn.LayerNorm(fused_latent_dim),
            nn.ReLU(),
            nn.Linear(fused_latent_dim, fused_latent_dim)
        )

    def forward(self, state_history: torch.Tensor) -> torch.Tensor:
        """
        state_history: Tensor of shape (batch_size, num_nodes, temporal_window, state_dim)
                       or (num_nodes, temporal_window, state_dim)
        Returns:
            fused_embeddings: Tensor of shape (batch_size, num_nodes, fused_latent_dim)
        """
        has_batch = (state_history.dim() == 4)
        if not has_batch:
            state_history = state_history.unsqueeze(0) # (1, N, Tw, D)

        batch_size, num_nodes, tw, d = state_history.shape

        # Reshape for GRU: treat (batch_size * num_nodes) as sequence batch
        gru_in = state_history.view(batch_size * num_nodes, tw, d)
        gru_out, h_n = self.temporal_gru(gru_in) # h_n is (1, B*N, hidden_dim)
        temp_features = h_n.squeeze(0).view(batch_size, num_nodes, -1) # (B, N, hidden_dim)

        # Spatial Relational Processing
        spatial_features = self.spatial_attn(temp_features) # (B, N, spatial_dim)

        # Extract current instantaneous state (last step of window) for content features
        current_state = state_history[:, :, -1, :] # (B, N, D)
        content_features = self.content_mlp(current_state) # (B, N, 32)

        # Concatenate and fuse
        fused = torch.cat([temp_features, spatial_features, content_features], dim=-1)
        latent_embeddings = self.fusion_network(fused)

        if not has_batch:
            latent_embeddings = latent_embeddings.squeeze(0)

        return latent_embeddings
