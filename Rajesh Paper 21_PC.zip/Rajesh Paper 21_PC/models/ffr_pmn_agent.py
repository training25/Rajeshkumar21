"""
Florist Optimization Algorithm based Federated Dynamic Reinforcement Policy Gradient
Mesh Network (FFR-PMN).
Implements distributed Actor-Critic agents for 6G Mesh Cluster Heads with
adaptive UE inclusion, continuous elastic resource control, and FOA-guided federated aggregation.
"""

import copy
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.distributions import Normal, Bernoulli
import numpy as np
from typing import Dict, List, Tuple

from .state_encoder import SpatioTemporalStateEncoder
from .florist_optimizer import FloristOptimizer


class ActorCriticNetwork(nn.Module):
    """
    Combined Actor-Critic network with In-Content Awareness.
    Outputs:
    - UE inclusion probabilities (Bernoulli logits)
    - Elastic resource allocation (Power, Bandwidth, Offload ratio) Gaussian distributions
    - State-Value estimate V(s)
    """
    def __init__(self, state_dim: int = 18, temporal_window: int = 5,
                 fused_latent_dim: int = 64):
        super(ActorCriticNetwork, self).__init__()
        self.encoder = SpatioTemporalStateEncoder(
            state_dim=state_dim,
            temporal_window=temporal_window,
            fused_latent_dim=fused_latent_dim
        )

        # Actor Heads
        # 1. In-Content Adaptive UE Inclusion Head
        self.actor_inclusion = nn.Sequential(
            nn.Linear(fused_latent_dim, 32),
            nn.ReLU(),
            nn.Linear(32, 1),
            nn.Sigmoid()
        )

        # 2. Continuous Elastic Resource Allocation Head (Power, BW, Offload)
        self.actor_resource_mean = nn.Sequential(
            nn.Linear(fused_latent_dim, 32),
            nn.ReLU(),
            nn.Linear(32, 3), # [Power_norm, BW_share_norm, Offload_ratio]
            nn.Sigmoid()
        )
        self.actor_resource_log_std = nn.Parameter(torch.ones(3) * -0.5)

        # Critic Head: Value function V(s)
        self.critic = nn.Sequential(
            nn.Linear(fused_latent_dim, 32),
            nn.ReLU(),
            nn.Linear(32, 1)
        )

    def forward(self, state_history: torch.Tensor):
        """
        Computes embeddings, inclusion probabilities, continuous resource means, and state value.
        """
        latent = self.encoder(state_history) # (N, fused_latent_dim)
        ue_inclusion_probs = self.actor_inclusion(latent).squeeze(-1) # (N,)
        resource_means = self.actor_resource_mean(latent) # (N, 3)
        values = self.critic(latent).squeeze(-1) # (N,)
        return ue_inclusion_probs, resource_means, values

    def evaluate_actions(self, state_history: torch.Tensor,
                         inclusion_actions: torch.Tensor,
                         resource_actions: torch.Tensor):
        """Evaluates log probabilities, entropy, and state values for PPO update."""
        ue_probs, res_means, values = self.forward(state_history)
        
        # Bernoulli log prob for inclusion
        bern_dist = Bernoulli(probs=torch.clamp(ue_probs, 1e-6, 1.0 - 1e-6))
        inclusion_log_probs = bern_dist.log_prob(inclusion_actions)
        inclusion_entropy = bern_dist.entropy()

        # Gaussian log prob for continuous resources
        std = torch.exp(self.actor_resource_log_std)
        norm_dist = Normal(res_means, std)
        res_log_probs = norm_dist.log_prob(resource_actions).sum(dim=-1)
        res_entropy = norm_dist.entropy().sum(dim=-1)

        total_log_probs = inclusion_log_probs + res_log_probs
        total_entropy = inclusion_entropy + res_entropy

        return total_log_probs, total_entropy, values


class MeshClusterAgent:
    """
    Local reinforcement policy gradient agent running at an individual 6G Mesh Router.
    Schedules and allocates resources for devices in its cluster.
    """
    def __init__(self, cluster_id: int, config: dict):
        self.cluster_id = cluster_id
        self.config = config
        self.state_dim = config['federated_rl']['state_dim']
        self.temporal_window = config['federated_rl']['temporal_window_size']
        
        self.model = ActorCriticNetwork(
            state_dim=self.state_dim,
            temporal_window=self.temporal_window
        )
        self.optimizer = optim.Adam([
            {'params': self.model.encoder.parameters(), 'lr': config['federated_rl']['actor_lr']},
            {'params': self.model.actor_inclusion.parameters(), 'lr': config['federated_rl']['actor_lr']},
            {'params': self.model.actor_resource_mean.parameters(), 'lr': config['federated_rl']['actor_lr']},
            {'params': [self.model.actor_resource_log_std], 'lr': config['federated_rl']['actor_lr']},
            {'params': self.model.critic.parameters(), 'lr': config['federated_rl']['critic_lr']}
        ])

        # Hyperparameters
        self.gamma = config['federated_rl']['gamma']
        self.gae_lambda = config['federated_rl']['gae_lambda']
        self.clip_eps = config['federated_rl']['clip_epsilon']
        self.local_epochs = config['federated_rl']['local_epochs']

        # Experience Memory
        self.states = []
        self.inclusion_actions = []
        self.resource_actions = []
        self.log_probs = []
        self.rewards = []
        self.values = []
        self.dones = []

    def select_action(self, state_history: np.ndarray, deterministic: bool = False) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Selects UE inclusion and elastic resource allocation.
        """
        self.model.eval()
        with torch.no_grad():
            state_tensor = torch.from_numpy(state_history).float()
            ue_probs, res_means, values = self.model(state_tensor)

            if deterministic:
                inc_act = (ue_probs >= 0.5).float()
                res_act = torch.clamp(res_means, 0.0, 1.0)
                log_prob = torch.zeros_like(ue_probs)
            else:
                # Sample inclusion
                bern_dist = Bernoulli(probs=torch.clamp(ue_probs, 1e-6, 1.0 - 1e-6))
                inc_act = bern_dist.sample()
                
                # Sample continuous resources
                std = torch.exp(self.model.actor_resource_log_std)
                norm_dist = Normal(res_means, std)
                res_act = torch.clamp(norm_dist.sample(), 0.0, 1.0)

                log_prob = bern_dist.log_prob(inc_act) + norm_dist.log_prob(res_act).sum(dim=-1)

        return inc_act.cpu().numpy(), res_act.cpu().numpy(), log_prob.cpu().numpy(), values.cpu().numpy()

    def store_transition(self, state, inc_act, res_act, log_prob, reward, value, done):
        self.states.append(state)
        self.inclusion_actions.append(inc_act)
        self.resource_actions.append(res_act)
        self.log_probs.append(log_prob)
        self.rewards.append(reward)
        self.values.append(value)
        self.dones.append(done)

    def compute_gae(self, last_value: float) -> Tuple[torch.Tensor, torch.Tensor]:
        """Computes Generalized Advantage Estimation (GAE)."""
        rewards = self.rewards
        values = self.values + [last_value]
        dones = self.dones

        advantages = []
        gae = 0.0
        for step in reversed(range(len(rewards))):
            delta = rewards[step] + self.gamma * values[step + 1] * (1.0 - dones[step]) - values[step]
            gae = delta + self.gamma * self.gae_lambda * (1.0 - dones[step]) * gae
            advantages.insert(0, gae)

        returns = [adv + val for adv, val in zip(advantages, values[:-1])]
        adv_tensor = torch.tensor(advantages, dtype=torch.float32)
        ret_tensor = torch.tensor(returns, dtype=torch.float32)

        # Normalize advantages
        if len(adv_tensor) > 1 and adv_tensor.std() > 1e-8:
            adv_tensor = (adv_tensor - adv_tensor.mean()) / (adv_tensor.std() + 1e-8)

        return adv_tensor, ret_tensor

    def train_local_policy(self, last_value: float) -> float:
        """Executes PPO updates over collected cluster rollouts."""
        num_steps = len(self.rewards)
        if num_steps == 0:
            return 0.0

        adv_tensor, ret_tensor = self.compute_gae(last_value)
        self.model.train()
        total_loss = 0.0

        for _ in range(self.local_epochs):
            epoch_loss = 0.0
            self.optimizer.zero_grad()
            for step_idx in range(num_steps):
                s = torch.tensor(self.states[step_idx], dtype=torch.float32)
                inc_a = torch.tensor(self.inclusion_actions[step_idx], dtype=torch.float32)
                res_a = torch.tensor(self.resource_actions[step_idx], dtype=torch.float32)
                old_lp = torch.tensor(self.log_probs[step_idx], dtype=torch.float32)
                adv = adv_tensor[step_idx]
                ret = ret_tensor[step_idx]

                curr_log_probs, entropy, curr_values = self.model.evaluate_actions(
                    s, inc_a, res_a
                )

                # Policy surrogate loss
                ratios = torch.exp(curr_log_probs - old_lp)
                surr1 = ratios * adv
                surr2 = torch.clamp(ratios, 1.0 - self.clip_eps, 1.0 + self.clip_eps) * adv
                policy_loss = -torch.min(surr1, surr2).mean()

                # Value function loss
                value_loss = F.mse_loss(curr_values.mean(), ret)

                # Entropy bonus
                entropy_loss = -0.01 * entropy.mean()

                step_loss = (policy_loss + 0.5 * value_loss + entropy_loss) / num_steps
                step_loss.backward()
                epoch_loss += step_loss.item()

            nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=0.5)
            self.optimizer.step()
            total_loss += epoch_loss

        # Clear memory
        self.states.clear()
        self.inclusion_actions.clear()
        self.resource_actions.clear()
        self.log_probs.clear()
        self.rewards.clear()
        self.values.clear()
        self.dones.clear()

        return total_loss / max(1, self.local_epochs)


class FFRPMAgent:
    """
    Orchestrates the Florist Optimization Algorithm based Federated dynamic
    Reinforcement Policy gradient Mesh Network (FFR-PMN).
    Coordinates cluster agents, aggregates federated models using FOA,
    and governs global 6G resource optimization.
    """
    def __init__(self, config: dict):
        self.config = config
        self.num_routers = config['network']['num_mesh_routers']
        
        # Instantiate local agents for each Mesh Router
        self.cluster_agents = [
            MeshClusterAgent(cluster_id=i, config=config)
            for i in range(self.num_routers)
        ]

        # Central Global Model
        self.global_model = ActorCriticNetwork(
            state_dim=config['federated_rl']['state_dim'],
            temporal_window=config['federated_rl']['temporal_window_size']
        )
        self.sync_local_agents_with_global()

        # Florist Optimizer for Meta-Aggregation
        foa_cfg = config['florist_optimizer']
        self.foa = FloristOptimizer(
            num_flowers=foa_cfg['population_size'],
            max_iter=foa_cfg['max_iterations'],
            dim=self.num_routers,
            lb=0.01,
            ub=1.0,
            scent_dispersion_rate=foa_cfg['scent_dispersion_rate'],
            aesthetic_arrangement_prob=foa_cfg['aesthetic_arrangement_prob'],
            seasonal_pruning_ratio=foa_cfg['seasonal_pruning_ratio']
        )
        self.aggregation_round = 0
        self.aggregation_weights = np.ones(self.num_routers) / self.num_routers

    def sync_local_agents_with_global(self):
        """Distributes global weights to all mesh cluster heads."""
        global_state = self.global_model.state_dict()
        for agent in self.cluster_agents:
            agent.model.load_state_dict(copy.deepcopy(global_state))

    def act_for_all_devices(self, env_devices: list, state_history: np.ndarray,
                            deterministic: bool = False) -> Dict[str, np.ndarray]:
        """
        Coordinates action generation across mesh clusters:
        Routes device states to their associated mesh cluster head's policy agent.
        """
        num_devices = len(env_devices)
        ue_inclusion = np.zeros(num_devices)
        power_alloc = np.zeros(num_devices)
        bw_share = np.zeros(num_devices)
        offload_ratio = np.zeros(num_devices)
        log_probs = np.zeros(num_devices)
        values = np.zeros(num_devices)

        # Group device indices by associated router
        router_device_map = {r_id: [] for r_id in range(self.num_routers)}
        for dev_idx, dev in enumerate(env_devices):
            router_device_map[dev.associated_router_id].append(dev_idx)

        # Each cluster agent decides for its associated IoT nodes
        for r_id, dev_indices in router_device_map.items():
            if not dev_indices:
                continue
            agent = self.cluster_agents[r_id]
            sub_history = state_history[dev_indices] # (Sub_N, Tw, D)

            inc, res, lp, vals = agent.select_action(sub_history, deterministic=deterministic)

            for local_k, global_idx in enumerate(dev_indices):
                ue_inclusion[global_idx] = inc[local_k]
                power_alloc[global_idx] = res[local_k, 0]
                bw_share[global_idx] = res[local_k, 1]
                offload_ratio[global_idx] = res[local_k, 2]
                log_probs[global_idx] = lp[local_k]
                values[global_idx] = vals[local_k]

        return {
            'ue_inclusion': ue_inclusion,
            'power_allocation': power_alloc,
            'bw_share': bw_share,
            'offload_ratio': offload_ratio,
            'log_probs': log_probs,
            'values': values
        }

    def store_distributed_rollout(self, env_devices: list, state_history: np.ndarray,
                                  actions: dict, reward: float, done: bool):
        """Stores experience tuples into respective cluster agents."""
        router_device_map = {r_id: [] for r_id in range(self.num_routers)}
        for dev_idx, dev in enumerate(env_devices):
            router_device_map[dev.associated_router_id].append(dev_idx)

        for r_id, dev_indices in router_device_map.items():
            if not dev_indices:
                continue
            agent = self.cluster_agents[r_id]
            sub_history = state_history[dev_indices]
            sub_inc = actions['ue_inclusion'][dev_indices]
            sub_res = np.stack([
                actions['power_allocation'][dev_indices],
                actions['bw_share'][dev_indices],
                actions['offload_ratio'][dev_indices]
            ], axis=-1)
            sub_lp = actions['log_probs'][dev_indices]
            sub_val = actions['values'][dev_indices]

            agent.store_transition(
                state=sub_history,
                inc_act=sub_inc,
                res_act=sub_res,
                log_prob=sub_lp,
                reward=reward,
                value=sub_val.mean(),
                done=done
            )

    def federated_aggregation_with_foa(self, cluster_performance_scores: List[float]):
        """
        Executes FOA-guided Federated Model Aggregation:
        Uses Florist Optimization to search for the optimal aggregation weighting vector omega
        that maximizes overall network performance and fairness.
        """
        self.aggregation_round += 1
        perf = np.array(cluster_performance_scores)
        
        # Define FOA objective function for federated weights
        def aggregation_fitness_obj(weights: np.ndarray) -> float:
            w_norm = weights / (np.sum(weights) + 1e-9)
            # Fitness combines weighted performance and diversity entropy
            entropy = -np.sum(w_norm * np.log(w_norm + 1e-9))
            weighted_perf = np.dot(w_norm, perf)
            return float(weighted_perf + 0.1 * entropy)

        # Run Florist Optimization
        best_weights, best_fit = self.foa.optimize(
            objective_func=aggregation_fitness_obj,
            initial_seed=self.aggregation_weights
        )
        self.aggregation_weights = best_weights / np.sum(best_weights)

        # Perform FOA-Weighted Federated Averaging
        global_dict = copy.deepcopy(self.cluster_agents[0].model.state_dict())
        for key in global_dict.keys():
            global_dict[key] = torch.zeros_like(global_dict[key], dtype=torch.float32)

        for r_id, agent in enumerate(self.cluster_agents):
            agent_dict = agent.model.state_dict()
            w = float(self.aggregation_weights[r_id])
            for key in global_dict.keys():
                global_dict[key] += w * agent_dict[key].to(torch.float32)

        self.global_model.load_state_dict(global_dict)
        self.sync_local_agents_with_global()
        return self.aggregation_weights
